#include "glSetup.h"

#ifdef _WIN32
#define _USE_MATH_DEFINES	// To include the definition of M_PI in math.h
#endif

#include <glm/glm.hpp>
#include <glm/gtx/string_cast.hpp>
#include <glm/gtc/type_ptr.hpp>
using namespace glm;

#include <iostream>
using namespace std;

void init();
void quit();
void render(GLFWwindow* window);
void keyboard(GLFWwindow* window, int key, int code, int action, int mods);

// Camera configuation
vec3 eye(3.5, 3, 3.5);
vec3 center(0, 0, 0);
vec3 up(0, 1, 0);

// Light configuration
vec4 light(5.0, 5.0, 5.0, 1);	// Light position

// Global coordinate frame
float AXIS_LENGTH = 3;
float AXIS_LINE_WIDTH = 2;

// Colors
GLfloat bgColor[4] = { 1,1,1,1 };

// Selected example
int selection = 1;

// Sphere, cylinder
GLUquadricObj* sphere = NULL;
GLUquadricObj* cylinder = NULL;
GLUquadricObj* disk = NULL;

// Paly configuration
bool pause = false;

float timeStep = 1.0f / 120;
float period = 4.0f;

// Current frame
int frame = 0;

int main(int argc, char* argv[])
{
    // vsync should be 0 for precise time stepping.
    vsync = 0;

    // Initialize the OpenGL system
    GLFWwindow* window = initializeOpenGL(argc, argv, bgColor);
    if (window == NULL)	return -1;

    // Callbacks
    glfwSetKeyCallback(window, keyboard);

    // Depth test
    glEnable(GL_DEPTH_TEST);

    // Normal vectors are normalized after transformation
    glEnable(GL_NORMALIZE);

    // Viewport and perspective setting
    reshape(window, windowW, windowH);

    // Initialization - Main loop - Finalization
    //
    init();

    //Main loop
    float previous = (float)glfwGetTime();
    float elapsed = 0;
    while (!glfwWindowShouldClose(window))
    {
        glfwPollEvents(); //Events

        float now = (float)glfwGetTime();
        float delta = now - previous;
        previous = now;

        elapsed += delta;

        if (elapsed > timeStep)
        {
            if (!pause)
            {
                frame += 1;
            }
            elapsed = 0;
        }
        render(window);
        glfwSwapBuffers(window);
    }

    quit();
    glfwDestroyWindow(window);
    glfwTerminate();

    return 0;
}

void init() {
    sphere = gluNewQuadric();
    gluQuadricDrawStyle(sphere, GLU_FILL);
    gluQuadricNormals(sphere, GLU_SMOOTH);
    gluQuadricOrientation(sphere, GLU_OUTSIDE);
    gluQuadricTexture(sphere, GLU_FALSE);

    cylinder = gluNewQuadric();
    gluQuadricDrawStyle(cylinder, GLU_FILL);
    gluQuadricNormals(cylinder, GLU_SMOOTH);
    gluQuadricOrientation(cylinder, GLU_OUTSIDE);
    gluQuadricTexture(cylinder, GLU_FALSE);

    disk = gluNewQuadric();
    gluQuadricDrawStyle(disk, GLU_FILL);
    gluQuadricNormals(disk, GLU_SMOOTH);
    gluQuadricOrientation(disk, GLU_OUTSIDE);
    gluQuadricTexture(disk, GLU_FALSE);


    cout << endl;
    cout << "Keyboard input:   space for play/pause" << endl;
    cout << endl;
    cout << "Keyboard input:   1 for Question1" << endl;
    cout << "Keyboard input:   2 for Question2" << endl;
    cout << "Keyboard input:   3 for Question3" << endl;
    cout << "Keyboard input:   4 for Question4" << endl;
    cout << "Keyboard input:   5 for Question5" << endl;
    cout << "Keyboard input:   6 for Question6" << endl;
}

void quit() {
    gluDeleteQuadric(sphere);
    gluDeleteQuadric(cylinder);
    gluDeleteQuadric(disk);
}

void setupLight() {
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);

    GLfloat ambient[4] = { 0.1f,0.1f ,0.1f ,1.0f };
    GLfloat diffise[4] = { 1.0f,1.0f ,1.0f ,1.0f };
    GLfloat specular[4] = { 0.1f,0.1f ,0.1f ,1.0f };

    glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, diffise);
    glLightfv(GL_LIGHT0, GL_SPECULAR, specular);
    glLightfv(GL_LIGHT0, GL_POSITION, value_ptr(light));
}

void setupMaterial() {
    // Material 
    GLfloat mat_ambient[4] = { 0.1f, 0.1f, 0.1f, 1.0f };
    GLfloat mat_specular[4] = { 0.5f, 0.5f, 0.5f, 1.0f };
    GLfloat mat_shininess = 128;
    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, mat_ambient);
    glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, mat_specular);
    glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, mat_shininess);
}

void setDiffuseColor(const vec3& color) {
    GLfloat mat_diffuse[4] = { color[0],color[1] ,color[2] ,1 };
    glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, mat_diffuse);
}



void mid1()
{
    // Cube
    glBegin(GL_QUADS);

    // Front
    glNormal3f(0, 0, 1);

    glVertex3f(0, 0, 1);
    glVertex3f(1, 0, 1);
    glVertex3f(1, 1, 1);
    glVertex3f(0, 1, 1);

    // Back
    glNormal3f(0, 0, -1);

    glVertex3f(0, 1, 0);
    glVertex3f(1, 1, 0);
    glVertex3f(1, 0, 0);
    glVertex3f(0, 0, 0);

    // Right
    glNormal3f(1, 0, 0);

    glVertex3f(1, 0, 1);
    glVertex3f(1, 0, 0);
    glVertex3f(1, 1, 0);
    glVertex3f(1, 1, 1);

    // Left
    glNormal3f(-1, 0, 0);

    glVertex3f(0, 1, 1);
    glVertex3f(0, 1, 0);
    glVertex3f(0, 0, 0);
    glVertex3f(0, 0, 1);

    // Top
    glNormal3f(0, 1, 0);

    glVertex3f(0, 1, 1);
    glVertex3f(1, 1, 1);
    glVertex3f(1, 1, 0);
    glVertex3f(0, 1, 0);

    // Bottom
    glNormal3f(0, -1, 0);

    glVertex3f(0, 0, 0);
    glVertex3f(1, 0, 0);
    glVertex3f(1, 0, 1);
    glVertex3f(0, 0, 1);

    glEnd();
}

void mid2()
{
    float s = 1.0f + 0.2f * sin(frame * 0.1f / period);
    
    glm::mat4   M(1.0f);
    M = glm::scale(M, glm::vec3(s, s, 1.0f));
    glMultMatrixf(value_ptr(M));
    setDiffuseColor(glm::vec3(1, 1, 1));
    mid1();
}

void mid3() {
    float s = 1.0f + 0.2f * sin(frame * 0.1f / period);
    glm::vec3   pivot(0.5, 0.5, 0.5);

    glm::mat4   M(1.0);

    M = glm::translate(M, pivot);
    M = glm::scale(M, glm::vec3(s, s, 1.0f));
    M = glm::translate(M, -pivot);

    glMultMatrixf(value_ptr(M));

    setDiffuseColor(glm::vec3(1, 1, 1));
    mid1();
}

void mid4() {
    float s = 1.0f + 0.2f * sin(frame * 0.1f / period);
    glm::vec3   pivot(0.5, 0.5, 0.0);

    glm::mat4   M(1.0);

    M = glm::translate(M, pivot);
    M = glm::scale(M, glm::vec3(s, s, 1.0f));
    M = glm::translate(M, -pivot);

    M = glm::translate(M, glm::vec3(0.5f,0.5f,0.0f));
    glMultMatrixf(value_ptr(M));

    setDiffuseColor(glm::vec3(1, 1, 1));
    mid1();
}

void mid5() {
    float theta1 = frame * 4 / period; // Degree
    glm::vec3   axis(0, 0, 1);
    float s = 1.0f + 0.2f * sin(frame * 0.1f / period);
    glm::vec3   pivot(0.5, 0.5, 0.0);

    glm::mat4   M(1.0);

   
    M = glm::translate(M, pivot);
    M = glm::rotate(M, glm::radians(theta1), axis);
    M = glm::scale(M, glm::vec3(s, s, 1.0f));
    
    M = glm::translate(M, -pivot);

    M = glm::translate(M, glm::vec3(0.5f, 0.5f, 0.0f));
    glMultMatrixf(value_ptr(M));

    setDiffuseColor(glm::vec3(1, 1, 1));
    mid1();
}

void mid6() {
    float theta1 = frame * 4 / period; // Degree
    glm::vec3   axis(0, 0, 1);
    float s = 1.0f + 0.2f * sin(frame * 0.1f / period);
    glm::vec3   pivot(0.5, 0.5, 0.0);

    glm::mat4   M(1.0);


    M = glm::translate(M, pivot);
    M = glm::rotate(M, glm::radians(theta1), axis);
    M = glm::scale(M, glm::vec3(s, s, 1.0f));

    M = glm::translate(M, -pivot);

    glMultMatrixf(value_ptr(M));

    setDiffuseColor(glm::vec3(1, 1, 1));
    mid1();
}
void render(GLFWwindow* window) {
    glClearColor(bgColor[0], bgColor[1], bgColor[2], bgColor[3]);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    gluLookAt(eye[0], eye[1], eye[2], center[0], center[1], center[2], up[0], up[1], up[2]);

    glDisable(GL_LIGHTING);
    drawAxes(AXIS_LENGTH, AXIS_LINE_WIDTH * dpiScaling);

    setupLight();
    setupMaterial();

    switch (selection)
    {
        case 1: mid1();  break;
        case 2: mid2();   break;
        case 3: mid3(); break;
        case 4: mid4(); break;
        case 5: mid5(); break;
        case 6: mid6(); break;
    }
}

void keyboard(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (action == GLFW_PRESS || action == GLFW_REPEAT)
    {
        switch (key) {
        case GLFW_KEY_Q:
        case GLFW_KEY_ESCAPE:   glfwSetWindowShouldClose(window, GL_TRUE); break;
        case GLFW_KEY_SPACE:    pause = !pause; break;
        case GLFW_KEY_1: selection = 1; break;
        case GLFW_KEY_2: selection = 2; break;
        case GLFW_KEY_3: selection = 3; break;
        case GLFW_KEY_4: selection = 4; break;
        case GLFW_KEY_5: selection = 5; break;
        case GLFW_KEY_6: selection = 6; break;
        }
    }
}