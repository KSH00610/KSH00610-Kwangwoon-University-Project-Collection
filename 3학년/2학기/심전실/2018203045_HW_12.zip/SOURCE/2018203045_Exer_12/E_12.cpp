#include "glSetup.h"

#include <glm/glm.hpp>
#include <glm/gtc/type_ptr.hpp>
using namespace glm;

#include <iostream>
#include <fstream>
using namespace std;

void init();
void quit();
void render(GLFWwindow* window);
void keyboard(GLFWwindow* window, int key, int code, int action, int mods);
void mouseButton(GLFWwindow* window, int button, int action, int mods);
void mouseMove(GLFWwindow* window, double x, double y);
void screen2world(float xs, float ys, float& xw, float& yw);

// Camera configuration
vec3 eyeTopView(0, 10, 0);
vec3 upTopView(0, 0, -1);

vec3 eyeFrontView(0, 0, 10);
vec3 upFrontView(0, 1, 0);

vec3 eyeBirdView(0, -10, 4);
vec3 upBirdView(0, 1, 0);
vec3 center(0, 0, 0);

float point[2][2] = { {0,0},{0,0} };



enum class InputMode
{
    NONE = 0,
    DRAGGING = 1,
    COMPLETE = 2,
};

InputMode inputMode = InputMode::NONE;


// Light configuration
vec4 light(0.0, 0.0, 0.8, 1);

// Global coordinate frame
bool axes = true;

float AXIS_LENGTH = 1.25;
float AXIS_LINE_WIDTH = 2;

// Colors
GLfloat bgColor[4] = { 1,1,1,1 };

// control variable
int view = 1; //Top, front, bird-eye view
int picked = -1;
double x_1=0;
double y_1=0;
double x_2=0;
double y_2=0;

double mid_x=0, mid_y=0;
double width=0, height=0;
bool select_sphere[9] = { false };


int main(int argc, char* argv[])
{
    fovy = 16.1f;

    // Initialize the OpenGL system
    GLFWwindow* window = initializeOpenGL(argc, argv, bgColor);
    if (window == NULL) return -1;

    // Callbacks
    glfwSetKeyCallback(window, keyboard);
    glfwSetMouseButtonCallback(window, mouseButton);
    glfwSetCursorPosCallback(window, mouseMove);

    // Depth test
    glEnable(GL_DEPTH_TEST);

    // Normal vectors are nomalized after transformation
    glEnable(GL_NORMALIZE);

    // VIewport and perspective setting
    reshape(window, windowW, windowH);

    // Initialization - Main loop - Finalization

    init();

    // Main loop    
    while (!glfwWindowShouldClose(window))
    {
        glfwPollEvents(); // Events

        render(window); // Draw one frame
        glfwSwapBuffers(window); // Swap buffers
    }

    // Finalization
    quit();

    // Terminate the glfw system
    glfwDestroyWindow(window);
    glfwTerminate();

    return 0;
}
GLUquadricObj* sphere = NULL;

void init()
{
    // Prepare quadric shapes
    sphere = gluNewQuadric();
    gluQuadricDrawStyle(sphere, GLU_FILL);
    gluQuadricNormals(sphere, GLU_SMOOTH);
    gluQuadricOrientation(sphere, GLU_OUTSIDE);
    gluQuadricTexture(sphere, GL_FALSE);

    // Keyboard
    cout << endl;
    cout << "Keyboard input : x for axes on/off" << endl;
    cout << "Keyboard input : v for the top, front, bird-eye view" << endl;
    cout << "Mouse button down: Select an object" << endl;
}

void quit()
{
    // Delete quadric shapes
    gluDeleteQuadric(sphere);
}

// Material
void setupColoredMaterial(const vec3& color)
{
    GLfloat mat_ambient[4] = { 0.1f,0.1f,0.1f,1.0f };
    GLfloat mat_diffuse[4] = { color[0],color[1],color[2],1.0f };
    GLfloat mat_specular[4] = { 0.5f,0.5f,0.5f,1.0f };
    GLfloat mat_shininess = 100.0f;

    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, mat_ambient);
    glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, mat_diffuse);
    glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, mat_specular);
    glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, mat_shininess);
}

void drawSphere(float radius, int slices, int stacks)
{
    gluSphere(sphere, radius, slices, stacks);
}
//Light
void setupLight(const vec4& p) {
    GLfloat ambient[4] = { 0.1f, 0.1f ,0.1f, 1.0f };
    GLfloat diffise[4] = { 1.0f, 1.0f, 1.0f, 1.0f };
    GLfloat specular[4] = { 1.0f, 1.0f, 1.0f, 1.0f };

    glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, diffise);
    glLightfv(GL_LIGHT0, GL_SPECULAR, specular);
    glLightfv(GL_LIGHT0, GL_POSITION, value_ptr(p));

}
void render(GLFWwindow* window)
{

    //Picking
    glInitNames();
    glPushName(-1);

    // Background color
    glClearColor(bgColor[0], bgColor[1], bgColor[2], bgColor[3]);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Modelview matrix
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    vec3 eye(0), up(0);
    switch (view)
    {
    case 0: eye = eyeTopView;    up = upTopView; break;
    case 1: eye = eyeFrontView;    up = upFrontView; break;
    case 2: eye = eyeBirdView;    up = upBirdView; break;
    }

    gluLookAt(eye[0], eye[1], eye[2], center[0], center[1], center[2], up[0], up[1], up[2]);

    if (view == 1) {
        if (inputMode == InputMode::DRAGGING)
        {
            glEnable(GL_LINE_STIPPLE);
            glLineStipple(int(3 * dpiScaling), 0xcccc);

            glBegin(GL_LINES);
            glVertex3f(point[0][0], point[0][1], 0);
            glVertex3f(point[0][0], point[1][1], 0);

            glVertex3f(point[0][0], point[1][1], 0);
            glVertex3f(point[1][0], point[1][1], 0);

            glVertex3f(point[1][0], point[1][1], 0);
            glVertex3f(point[1][0], point[0][1], 0);

            glVertex3f(point[1][0], point[0][1], 0);
            glVertex3f(point[0][0], point[0][1], 0);
        }
    }
    else if (view == 2) {
        if (inputMode == InputMode::DRAGGING)
        {
            glEnable(GL_LINE_STIPPLE);
            glLineStipple(int(3 * dpiScaling), 0xcccc);

            glBegin(GL_LINES);
            glVertex3f(point[0][0], 0, point[0][1]);
            glVertex3f(point[0][0], 0, point[1][1]);

            glVertex3f(point[0][0], 0, point[1][1]);
            glVertex3f(point[1][0], 0, point[1][1]);

            glVertex3f(point[1][0], 0, point[1][1]);
            glVertex3f(point[1][0], 0, point[0][1]);

            glVertex3f(point[1][0], 0, point[0][1]);
            glVertex3f(point[0][0], 0, point[0][1]);
        }
    }
    else if(view==0) {
        if (inputMode == InputMode::DRAGGING)
        {
            glEnable(GL_LINE_STIPPLE);
            glLineStipple(int(3 * dpiScaling), 0xcccc);

            glBegin(GL_LINES);
            

            glVertex3f(point[0][1], 0, point[0][0]);
            glVertex3f(point[1][1], 0, point[0][0]);

           glVertex3f(point[1][1], 0, point[0][0]);
            glVertex3f(point[1][1], 0, point[1][0]);

            glVertex3f(point[1][1], 0, point[1][0]);
            glVertex3f(point[0][1], 0, point[1][0]);

            glVertex3f(point[0][1], 0, point[1][0]);
            glVertex3f(point[0][1], 0, point[0][0]);
         

        }
    }
    // Axes
    if (axes)
    {
        glDisable(GL_LIGHTING);
        glDisable(GL_LINE_STIPPLE);
        drawAxes(AXIS_LENGTH, AXIS_LINE_WIDTH * dpiScaling);
    }




    glShadeModel(GL_SMOOTH);

    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);

    setupLight(light);

    glScalef(0.4f, 0.4f, 0.4f);

    vec3 u[3];
    vec3 v[3];
    u[0] = vec3(0, 1, 0) * 2.0f;    u[1] = vec3(0, 0, 0);   u[2] = -u[0];
    v[0] = -vec3(1, 0, 0) * 4.0f;    v[1] = vec3(0, 0, 0);   v[2] = -v[0];

    for (int i = 0; i < 3; i++) {
        glPushMatrix();
        glTranslatef(u[i].x, u[i].y, u[i].z);
        for (int j = 0; j < 3; j++) {
            glPushMatrix();
            glTranslatef(v[j].x, v[j].y, v[j].z);

            if (select_sphere[3*i+j] == true || picked == 3*i+j)setupColoredMaterial(vec3(0, 0, 1));
            else setupColoredMaterial(vec3(1, 1, 1));

            glLoadName(3 * i + j);

            drawSphere(0.7f, 64, 64);

            glPopMatrix();
        }
        glPopMatrix();
    }



}



void keyboard(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (action == GLFW_PRESS || action == GLFW_REPEAT)
    {
        switch (key)
        {
            // Quit
        case GLFW_KEY_Q:
        case GLFW_KEY_ESCAPE: glfwSetWindowShouldClose(window, GL_TRUE); break;

            // Axes
        case GLFW_KEY_X: axes = !axes; break;

        case GLFW_KEY_V: view = (view + 1) % 3; break;
        }
    }
}

int findNearestHits(int hits, GLuint selectBuffer[64])
{
    bool diagnosis = true;

    if (diagnosis)cout << "hits = " << hits << endl;

    int name = -1;
    float nearest = 2.0;

    int index = 0;

    for (int i = 0; i < hits; i++) {
        int n = selectBuffer[index + 0];
        float z1 = (float)selectBuffer[index + 1] / 0xffffffff;
        float z2 = (float)selectBuffer[index + 2] / 0xffffffff;

        if (z1 < nearest) { nearest = z1; name = selectBuffer[index + 3]; }

        if (diagnosis)
        {
            cout << "\t# of names = " << n << endl;
            cout << "\tz1 = " << z1 << endl;
            cout << "\tz2 = " << z2 << endl;
            cout << "\tnames: ";
            for (int j = 0; j < n; j++) {
                cout << selectBuffer[index + 3 + j] << " ";
                if (selectBuffer[index + 3 + j] >= 0 && selectBuffer[index + 3 + j] < 9) {
                    select_sphere[selectBuffer[index + 3 + j]] = true;
                }
            }
                

            cout << endl;
        }

        index += (3 + n);
    }
    if (diagnosis) cout << "picked = " << name << endl;

    return name;
}

int selectObjects(GLFWwindow* window, double x, double y)
{
    double delX = width;
    double delY = height;
    for (int i = 0; i < 9; i++) {
        select_sphere[i] = false;
    }

    GLuint selectBuffer[64];
    glSelectBuffer(64, selectBuffer);

    GLint viewport[4];
    glGetIntegerv(GL_VIEWPORT, viewport);

    glMatrixMode(GL_PROJECTION);
    glPushMatrix();

    glLoadIdentity();

    gluPickMatrix(x, viewport[3] - y, delX, delY, viewport);

    setupProjectionMatrix();

    glRenderMode(GL_SELECT);

    render(window);

    GLint hits = glRenderMode(GL_RENDER);
    int name = findNearestHits(hits, selectBuffer);
    
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();

    return name;
}
void screen2world(float xs, float ys, float& xw, float& yw)
{
    float aspect = (float)screenW / screenH;
    xw = 2.8f * (xs / (screenW - 1) - 0.5f) * aspect;
    yw = -2.8f * (ys / (screenH - 1) - 0.5f);
   
}

void mouseButton(GLFWwindow* window, int button, int action, int mods)
{
   
    if (action == GLFW_PRESS && button == GLFW_MOUSE_BUTTON_LEFT)
    {
        double xs, ys;
        glfwGetCursorPos(window, &xs, &ys);

            x_1 = xs * dpiScaling;
            y_1 = ys * dpiScaling;
            float xw, yw;
            screen2world((float)xs, (float)ys, xw, yw);
            inputMode = InputMode::DRAGGING;
            point[0][0] = xw;
            point[0][1] = yw;

            point[1][0] = xw;
            point[1][1] = yw;

        }
        if (action == GLFW_RELEASE && button == GLFW_MOUSE_BUTTON_LEFT) {
            double xs, ys;
            glfwGetCursorPos(window, &xs, &ys);
            x_2 = xs * dpiScaling;
            y_2 = ys * dpiScaling;
            float xw, yw;
            screen2world((float)xs, (float)ys, xw, yw);
            inputMode = InputMode::COMPLETE;
            width = (fabs(x_2 - x_1)) * dpiScaling;
            height = (fabs(y_2 - y_1)) * dpiScaling;
            mid_x = ((x_2 + x_1) / 2.0) * dpiScaling;
            mid_y = ((y_2 + y_1) / 2.0) * dpiScaling;
            point[1][0] = xw;
            point[1][1] = yw;
        }
        picked = selectObjects(window, mid_x, mid_y);
    

}

void mouseMove(GLFWwindow* window, double x, double y)
{
    if (inputMode == InputMode::DRAGGING)
    {
        screen2world((float)x, (float)y, point[1][0], point[1][1]);
    }
}