#include "glSetup.h"
#ifdef _WIN32
#define _USE_MATH_DEFINES
#endif

#include <glm/glm.hpp>
#include <glm/gtc/type_ptr.hpp>
using namespace glm;

#include <iostream>
#include <fstream>
#include <math.h>
using namespace std;

void init();
void quit();
void render(GLFWwindow* window);
void keyboard(GLFWwindow* window, int key, int code, int action, int mods);


int sel = 1;
// Camera configuration
vec3 eyeTopView(0, 10, 0);
vec3 upTopView(0, 0, -1);

vec3 eyeFrontView(0, 0, 10);
vec3 upFrontView(0, 1, 0);

vec3 eyeBirdView(0, -10, 4);
vec3 upBirdView(0, 1, 0);
vec3 center(0, 0, 0);

vec3 eye(5, 5, 5);
vec3 up(0, 1, 0);

// Light configuration
//vec4 light(5.0, 5.0, 0.0, 1); // light position
vec4 lightInitialP(0.0, 0.5, 0.5, 1); // Light position

// Global coordinate frame
bool axes = true;

float AXIS_LENGTH = 1.75;
float AXIS_LINE_WIDTH = 2;

// Colors
GLfloat bgColor[4] = { 1,1,1,1 };

// control variable
int view = 2;


bool rotationObject = false;
bool rotationLight = false;

float thetaModel = 0;
float thetaLight[3];

bool lightOn[3];
bool attenuation = false;

bool exponent = false;
float exponentInitial = 0.0;
float exponentValue = exponentInitial;
float exponentNorm = exponentValue / 128.0f;

bool cutoff = false;
float cutoffMax = 60;
float cutoffInitial = 30.0;
float cutoffValue = cutoffInitial;
float cutoffNorm = cutoffValue / cutoffMax;

int material = 0;

// Paly configuration
bool pause = true;

float timeStep = 1.0f / 120; // 120fps
float period = 4.0;
float theta = 0;
// Current frame
int frame = 0;
bool polygonFill = false;
void reinitialize() {
    frame = 0;

    lightOn[0] = true;
    lightOn[1] = false;
    lightOn[2] = false;

    thetaModel = 0;
    for (int i = 0; i < 3; i++)
        thetaLight[i] = 0;

    exponentValue = exponentInitial;
    exponentNorm = exponentValue / 128.0f;

    cutoffValue = cutoffInitial;
    cutoffNorm = cutoffValue / cutoffMax;
}

void animate() {
    frame += 1;

    if (rotationLight)
    {
        for (int i = 0; i < 3; i++) {
            if (lightOn[i])  thetaLight[i] += 4 / period;
        }
    }

    if (rotationObject)  thetaModel += 4 / period;

    if (lightOn[2] && exponent) {
        exponentNorm += float(radians(4.0 / period) / M_PI);
        exponentValue = float(128.0f * (acos(cos(exponentNorm * M_PI)) / M_PI));
    }
    if (lightOn[2] && cutoff) {
        cutoffNorm += float(radians(4.0 / period) / M_PI);
        cutoffValue = float(cutoffMax * (acos(cos(cutoffNorm * M_PI)) / M_PI));
    }
}
int main(int argc, char* argv[])
{
    // vsync should be 0 for precise time stepping
    vsync = 0;

    fovy = 16.1f;

    // Initialize the OpenGL system
    GLFWwindow* window = initializeOpenGL(argc, argv, bgColor);
    if (window == NULL) return -1;

    // Callbacks
    glfwSetKeyCallback(window, keyboard);

    // Depth test
    glEnable(GL_DEPTH_TEST);

    // Normal vectors are nomalized after transformation
    glEnable(GL_NORMALIZE);

    // VIewport and perspective setting
    reshape(window, windowW, windowH);

    // Initialization - Main loop - Finalization

    init();

    // Main loop
    float previous = (float)glfwGetTime();
    float elapsed = 0;
    while (!glfwWindowShouldClose(window))
    {
        glfwPollEvents(); // Events

        // Time passed during a single loop
        float now = (float)glfwGetTime();
        float delta = now - previous;
        previous = now;

        // Time passed after the previous frame
        elapsed += delta;

        // Deal with the current frame
        if (elapsed > timeStep)
        {
            // Animate 1 frame
            if (!pause) animate();

            elapsed = 0; // Reset the elapsed time
        }
        render(window); // Draw one frame
        glfwSwapBuffers(window); // Swap buffers
    }

    // Finalization
    quit();

    // Terminate the glfw system
    glfwDestroyWindow(window);
    glfwTerminate();

    return 0;
}
GLUquadricObj* sphere = NULL;
GLUquadricObj* cylinder = NULL;
GLUquadricObj* cone = NULL;
void init()
{
    reinitialize();
    // Prepare quadric shapes
    sphere = gluNewQuadric();
    gluQuadricDrawStyle(sphere, GLU_FILL);
    gluQuadricNormals(sphere, GLU_SMOOTH);
    gluQuadricOrientation(sphere, GLU_OUTSIDE);
    gluQuadricTexture(sphere, GL_FALSE);

    cylinder = gluNewQuadric();
    gluQuadricDrawStyle(cylinder, GLU_FILL);
    gluQuadricNormals(cylinder, GLU_SMOOTH);
    gluQuadricOrientation(cylinder, GLU_OUTSIDE);
    gluQuadricTexture(cylinder, GL_FALSE);

    cone = gluNewQuadric();
    gluQuadricDrawStyle(cone, GLU_FILL);
    gluQuadricNormals(cone, GLU_SMOOTH);
    gluQuadricOrientation(cone, GLU_OUTSIDE);
    gluQuadricTexture(cone, GL_FALSE);




    // Keyboard
    cout << endl;
    cout << "Keyboard input : space for play/pause" << endl;
    cout << "Keyboard input : i for reinitialization" << endl;

    cout << "Keyboard input : v for the top, front, bird-eye view" << endl;
    cout << "Keyboard input : p for a point light" << endl;
    cout << "Keyboard input : d for a distant light" << endl;
    cout << "Keyboard input : s for a spot light" << endl;
    cout << "Keyboard input : a for light attenuation" << endl;


    cout << "Keyboard input : l for rotation of lights" << endl;
    cout << "Keyboard input : o for rotation of objects" << endl;

    cout << "Keyboard input : left for decrease angle" << endl;
    cout << "Keyboard input : right for increase angle" << endl;
    cout << "Keyboard input : up for increasing shininess coefficient" << endl;
    cout << "Keyboard input : down for decreasing shininess coefficient" << endl;
}

void quit()
{
    // Delete quadric shapes
    gluDeleteQuadric(sphere);
    gluDeleteQuadric(cylinder);
    gluDeleteQuadric(cone);


}
GLfloat ma = 100;
// Light
void setupColoredMaterial(const vec3& color)
{
    GLfloat mat_ambient[4] = { 0.1f,0.1f,0.1f,1.0f };
    GLfloat mat_diffuse[4] = { color[0],color[1],color[2],1.0f };
    GLfloat mat_specular[4] = { 0.5f,0.5f,0.5f,1.0f };

    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, mat_ambient);
    glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, mat_diffuse);
    glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, mat_specular);
    glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, ma);
}


void drawSquare() {
    glBegin(GL_QUADS);

    glNormal3f(0, 0, 1);
    glVertex3f(0, 0, 1);
    glVertex3f(1, 0, 1);
    glVertex3f(1, 1, 1);
    glVertex3f(0, 1, 1);

    glEnd();
}
void drawSphere(float radius, int slices, int stacks)
{
    gluSphere(sphere, radius, slices, stacks);
}
void drawCylinder(float radius, float height, int slices, int stacks) {
    gluCylinder(cylinder, radius, radius, height, slices, stacks);
}
void drawCone(float radius, float height, int slices, int stacks) {
    gluCylinder(cone, 0, radius, height, slices, stacks);
}
void setDiffuseColor(const vec3& color) {
    GLfloat mat_diffuse[4] = { color[0],color[1] ,color[2] ,1 };
    glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, mat_diffuse);
}

int cnt = 1;
glm::vec3* vertex = NULL;
glm::vec3* vnormal = NULL;
glm::vec3* mid = NULL;
glm::vec3* fnormal = NULL; // Face normal

GLfloat mat_blue[4] = { 0.0f, 0.0f, 1.0f, 1.0f };
GLfloat mat_red[4] = { 1.0f, 0.0f, 0.0f, 1.0f };

void drawTourus() {
    setDiffuseColor(vec3(0, 0, 0));
    glPointSize(3 * dpiScaling);


    float PI = M_PI;

    float theata1 = 2 * PI / 18;
    float theata2 = 2 * PI / 36;

    vertex = new glm::vec3[36 * 18];
    fnormal = new glm::vec3[36 * 18];
    vnormal = new glm::vec3[36 * 18];
    mid = new glm::vec3[36 * 18];

    for (int i = 0; i < 36 * 18; i++) {
        vertex[i] = vec3(0.2, 0.2, 0);
        fnormal[i] = vec3(0, 0, 0);
        vnormal[i] = vec3(0, 0, 0);
        mid[i] = vec3(0, 0, 0);
    }

    for (int i = 0; i < 18; i++) {
        float c = cos(theata1);
        float s = sin(theata1);
        glm::mat4 T(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0.5, 0.5, 0, 1);
        glm::vec4 temp(vertex[i].x, vertex[i].y, vertex[i].z, 1);
        if (i < 17) {
            glm::mat3 R(c, s, 0, -s, c, 0, 0, 0, 1);
            vertex[i + 1] = R * vertex[i];
            temp = T * temp;
            vertex[i].x = temp.x;
            vertex[i].y = temp.y;
            vertex[i].z = temp.z;
        }
        else {
            temp = T * temp;
            vertex[i].x = temp.x;
            vertex[i].y = temp.y;
            vertex[i].z = temp.z;
        }
    }
    for (int i = 1; i < 36; i++) {
        float c = cos(theata2);
        float s = sin(theata2);
        glm::mat3 R(c, 0, -s, 0, 1, 0, s, 0, c);
        for (int j = 0; j < 18; j++) {
            vertex[18 * i + j] = R * vertex[18 * (i - 1) + j];
        }
    }


    for (int i = 0; i < 36; i++) {
        for (int j = 0; j < 18; j++) {
            mid[18 * i + j].x = (vertex[18 * (i % 36) + (j % 18)].x + vertex[18 * (i % 36) + ((j + 1) % 18)].x + vertex[18 * ((i + 1) % 36) + ((j + 1) % 18)].x + vertex[18 * ((i + 1) % 36) + (j % 18)].x) / 4.0f;
            mid[18 * i + j].y = (vertex[18 * (i % 36) + (j % 18)].y + vertex[18 * (i % 36) + ((j + 1) % 18)].y + vertex[18 * ((i + 1) % 36) + ((j + 1) % 18)].y + vertex[18 * ((i + 1) % 36) + (j % 18)].y) / 4.0f;
            mid[18 * i + j].z = (vertex[18 * (i % 36) + (j % 18)].z + vertex[18 * (i % 36) + ((j + 1) % 18)].z + vertex[18 * ((i + 1) % 36) + ((j + 1) % 18)].z + vertex[18 * ((i + 1) % 36) + (j % 18)].z) / 4.0f;

        }
    }

    for (int i = 0; i < 36; i++) {
        for (int j = 0; j < 18; j++) {
            int p1 = 18 * (i % 36) + (j % 18);
            int p2 = 18 * (i % 36) + ((j + 1) % 18);
            int p3 = 18 * ((i + 1) % 36) + (j % 18);
            int p4 = 18 * ((i + 1) % 36) + ((j + 1) % 18);
            vec3 v = normalize(cross(vertex[p2] - vertex[p1], vertex[p3] - vertex[p1]));
            fnormal[p1] = -v;
            vnormal[p1] += v;

        }
    }
    for (int i = 0; i < 18 * 36; i++) {
        vnormal[i] = normalize(vnormal[i]);
    }

  
    
        for (int i = 0; i < cnt; i++) {
            for (int j = 0; j < 18; j++) {
                int p1 = 18 * (i % 36) + (j % 18);
                int p2 = 18 * (i % 36) + ((j + 1) % 18);
                int p3 = 18 * ((i + 1) % 36) + ((j + 1) % 18);
                int p4 = 18 * ((i + 1) % 36) + (j % 18);


                glDisable(GL_CULL_FACE);
                glLightModeli(GL_LIGHT_MODEL_TWO_SIDE, GL_TRUE);
                glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
                glPolygonOffset(1.0f, 1.0f);



                glBegin(GL_QUADS);

                if (dot(fnormal[18 * i + j], eye - mid[18 * i + j]) < 0) {
                    glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_red);
                }
                else {
                    glMaterialfv(GL_BACK, GL_DIFFUSE, mat_blue);
                }
                glNormal3fv(value_ptr(vnormal[p1]));
                glVertex3fv(value_ptr(vertex[p1]));

                glNormal3fv(value_ptr(vnormal[p2]));
                glVertex3fv(value_ptr(vertex[p2]));

                glNormal3fv(value_ptr(vnormal[p3]));
                glVertex3fv(value_ptr(vertex[p3]));

                glNormal3fv(value_ptr(vnormal[p4]));
                glVertex3fv(value_ptr(vertex[p4]));

                glEnd();


            }
        }
    
    if (sel == 2) {
        for (int i = 0; i < cnt; i++) {
            for (int j = 0; j < 18; j++) {
                int p1 = 18 * (i % 36) + (j % 18);
               
                glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
                glBegin(GL_QUADS);

                glColor3f(0.0, 0.0, 0.0);
                glVertex3f(vertex[18 * (i % 36) + (j % 18)].x, vertex[18 * (i % 36) + (j % 18)].y, vertex[18 * (i % 36) + (j % 18)].z);
                glColor3f(0.0, 0.0, 0.0);
                glVertex3f(vertex[18 * (i % 36) + ((j + 1) % 18)].x, vertex[18 * (i % 36) + ((j + 1) % 18)].y, vertex[18 * (i % 36) + ((j + 1) % 18)].z);
                glColor3f(0.0, 0.0, 0.0);
                glVertex3f(vertex[18 * ((i + 1) % 36) + ((j + 1) % 18)].x, vertex[18 * ((i + 1) % 36) + ((j + 1) % 18)].y, vertex[18 * ((i + 1) % 36) + ((j + 1) % 18)].z);
                glColor3f(0.0, 0.0, 0.0);
                glVertex3f(vertex[18 * ((i + 1) % 36) + (j % 18)].x, vertex[18 * ((i + 1) % 36) + (j % 18)].y, vertex[18 * ((i + 1) % 36) + (j % 18)].z);
                glEnd();
            }
        }
    }
    if (sel == 3) {
        for (int i = 0; i < cnt; i++) {
            for (int j = 0; j < 18; j++) {
                int p1 = 18 * (i % 36) + (j % 18);
                
                glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
                glBegin(GL_QUADS);

                glColor3f(0.0, 0.0, 0.0);
                glVertex3f(vertex[18 * (i % 36) + (j % 18)].x, vertex[18 * (i % 36) + (j % 18)].y, vertex[18 * (i % 36) + (j % 18)].z);
                glColor3f(0.0, 0.0, 0.0);
                glVertex3f(vertex[18 * (i % 36) + ((j + 1) % 18)].x, vertex[18 * (i % 36) + ((j + 1) % 18)].y, vertex[18 * (i % 36) + ((j + 1) % 18)].z);
                glColor3f(0.0, 0.0, 0.0);
                glVertex3f(vertex[18 * ((i + 1) % 36) + ((j + 1) % 18)].x, vertex[18 * ((i + 1) % 36) + ((j + 1) % 18)].y, vertex[18 * ((i + 1) % 36) + ((j + 1) % 18)].z);
                glColor3f(0.0, 0.0, 0.0);
                glVertex3f(vertex[18 * ((i + 1) % 36) + (j % 18)].x, vertex[18 * ((i + 1) % 36) + (j % 18)].y, vertex[18 * ((i + 1) % 36) + (j % 18)].z);
                glEnd();

                glBegin(GL_LINES);
                
                glVertex3fv(value_ptr(vertex[p1]));
                glVertex3fv(value_ptr(vertex[p1] + normalize(vnormal[p1])));
                glEnd();
            }
        }
    }
    
}


//Compute the rotation axis and angle from a to b
//
//Axis is not normalized
//theta is represented in degrees
//
void computeRotation(const vec3& a, const vec3& b, float& theta, vec3& axis) {
    axis = cross(a, b);
    float sinTheta = length(axis);
    float cosTheta = dot(a, b);
    theta = float(atan2(sinTheta, cosTheta) * 180.0 / M_PI);
}

void setupLight(const vec4& p, int i) {
    GLfloat ambient[4] = { 0.1f,0.1f ,0.1f ,1.0f };
    GLfloat diffise[4] = { 1.0f,1.0f ,1.0f ,1.0f };
    GLfloat specular[4] = { 0.1f,0.1f ,0.1f ,1.0f };

    glLightfv(GL_LIGHT0 + i, GL_AMBIENT, ambient);
    glLightfv(GL_LIGHT0 + i, GL_DIFFUSE, diffise);
    glLightfv(GL_LIGHT0 + i, GL_SPECULAR, specular);
    glLightfv(GL_LIGHT0 + i, GL_POSITION, value_ptr(p));

    if ((i == 0 || i == 2) && attenuation) {
        glLightf(GL_LIGHT0 + i, GL_CONSTANT_ATTENUATION, 1.0f);
        glLightf(GL_LIGHT0 + i, GL_LINEAR_ATTENUATION, 0.1f);
        glLightf(GL_LIGHT0 + i, GL_QUADRATIC_ATTENUATION, 0.05f);
    }
    else {
        glLightf(GL_LIGHT0 + i, GL_CONSTANT_ATTENUATION, 1.0f);
        glLightf(GL_LIGHT0 + i, GL_LINEAR_ATTENUATION, 0.0f);
        glLightf(GL_LIGHT0 + i, GL_QUADRATIC_ATTENUATION, 0.0f);
    }

    if (i == 2) {
        vec3 spotDirection = -vec3(p);
        glLightfv(GL_LIGHT0 + i, GL_SPOT_DIRECTION, value_ptr(spotDirection));
        glLightf(GL_LIGHT0 + i, GL_SPOT_CUTOFF, cutoffValue);
        glLightf(GL_LIGHT0 + i, GL_SPOT_EXPONENT, exponentValue);
    }
    else {
        glLightf(GL_LIGHT0 + i, GL_SPOT_CUTOFF, 180);
    }
}

void drawArrow(const vec3& p, bool tailOnly) {
    glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);
    glEnable(GL_COLOR_MATERIAL);

    GLfloat mat_specular[4] = { 1,1,1,1 };
    GLfloat mat_shiness = 25;
    glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, mat_specular);
    glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, mat_shiness);

    glPushMatrix();

    glTranslatef(p.x, p.y, p.z);

    if (!tailOnly) {
        float theta;
        vec3 axis;
        computeRotation(vec3(0, 0, 1), vec3(0, 0, 0) - vec3(p), theta, axis);
        glRotatef(theta, axis.x, axis.y, axis.z);
    }

    float arrowTailRadius = 0.05f;
    glColor3f(1, 0, 0);
    drawSphere(arrowTailRadius, 16, 16);

    if (!tailOnly) {
        float arrowShaftRadius = 0.02f;
        float arrowShaftLength = 0.2f;
        glColor3f(0, 1, 0);
        drawCylinder(arrowShaftRadius, arrowShaftLength, 16, 5);

        float arrowheadHeight = 0.09f;
        float arrowheadRadius = 0.06f;
        glTranslatef(0, 0, arrowShaftLength + arrowheadHeight);
        glRotatef(180, 1, 0, 0);
        glColor3f(0, 0, 1); //ambient and diffuse
        drawCone(arrowheadRadius, arrowheadHeight, 16, 5);
    }

    glPopMatrix();

    glDisable(GL_COLOR_MATERIAL);
}

void drawSpotLight(const vec3& p, float cutoff) {
    glPushMatrix();

    glTranslatef(p.x, p.y, p.z);

    float theta;
    vec3 axis;
    computeRotation(vec3(0, 0, 1), vec3(0, 0, 0) - vec3(p), theta, axis);
    glRotatef(theta, axis.x, axis.y, axis.z);

    setupColoredMaterial(vec3(0, 0, 1));

    float h = 0.15f;
    float r = h * tan(radians(cutoff));
    drawCone(r, h, 16, 5);

    setupColoredMaterial(vec3(1, 0, 0));

    float apexRadius = 0.06f * (0.5f + exponentValue / 128.0f);
    drawSphere(apexRadius, 16, 16);

    glPopMatrix();
}

void setupLight() {
    GLfloat ambient[4] = { 0.1f,0.1f ,0.1f ,0.1f };
    GLfloat diffise[4] = { 1.0f,1.0f ,1.0f ,1.0f };
    GLfloat specular[4] = { 1.0f,1.0f ,1.0f ,1.0f };

    glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, diffise);
    glLightfv(GL_LIGHT0, GL_SPECULAR, specular);
    glLightfv(GL_LIGHT0, GL_POSITION, value_ptr(lightInitialP));

}

void setupMaterial() {
    // Material 
    GLfloat mat_ambient[4] = { 0.1f, 0.1f, 0.1f, 1.0f };
    GLfloat mat_specular[4] = { 0.5f, 0.5f, 0.5f, 1.0f };
    GLfloat mat_shininess = 128;
    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, mat_ambient);
    glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, mat_specular);
    glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, mat_shininess);
}

void render(GLFWwindow* window) {
    glClearColor(bgColor[0], bgColor[1], bgColor[2], bgColor[3]);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    gluLookAt(eye[0], eye[1], eye[2], center[0], center[1], center[2], up[0], up[1], up[2]);


    drawAxes(AXIS_LENGTH, AXIS_LINE_WIDTH * dpiScaling);
    glShadeModel(GL_SMOOTH);
    glRotatef(degrees(theta), 0, 1, 0);
    glDisable(GL_CULL_FACE);
    glLightModeli(GL_LIGHT_MODEL_TWO_SIDE, GL_TRUE);

    //Rotation of the light or 3x3 models
    vec3 axis(0, 1, 0);


    glEnable(GL_LIGHTING);

    //set up the lights
    vec4 lightP[3];
    for (int i = 0; i < 3; i++) {
        //just turn off the i-th light, if not lit
        if (!lightOn[i]) { glDisable(GL_LIGHT0 + i); continue; }

        //Turn on the i-th light
        glEnable(GL_LIGHT0 + i);

        //Dealing with the distant light
        lightP[i] = lightInitialP;
        if (i == 1) lightP[i].w = 0;

        //Lights rotate around the center of the world coordinate system
        mat4 R = rotate(mat4(1.0), radians(thetaLight[i]), axis);;
        lightP[i] = R * lightP[i];

        //Set up the i-th light
        setupLight(lightP[i], i);
    }

    //Draw the geometries of the lights
    for (int i = 0; i < 3; i++) {
        if (!lightOn[i]) continue;

        if (i == 2)drawSpotLight(lightP[i], cutoffValue);
        else drawArrow(lightP[i], i == 0);//Tail only for a point light
    }
    glScalef(0.4f, 0.4f, 0.4f);
    drawTourus();
}

void keyboard(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (action == GLFW_PRESS || action == GLFW_REPEAT)
    {
        switch (key)
        {
            // Quit
        case GLFW_KEY_Q:
        case GLFW_KEY_ESCAPE: glfwSetWindowShouldClose(window, GL_TRUE); break;

            //Initialization
        case GLFW_KEY_I: reinitialize(); break;

            // Play on/off
        case GLFW_KEY_SPACE: pause = !pause; break;

        case GLFW_KEY_P: lightOn[0] = !lightOn[0]; break;
        case GLFW_KEY_D: lightOn[1] = !lightOn[1]; break;
        case GLFW_KEY_S: lightOn[2] = !lightOn[2]; break;
        case GLFW_KEY_O: polygonFill = !polygonFill; break;
        case GLFW_KEY_L: rotationLight = !rotationLight; break;

        case GLFW_KEY_1: sel = 1; break;
        case GLFW_KEY_2: sel = 2; break;
        case GLFW_KEY_3: sel = 3; break;
        case GLFW_KEY_4: sel = 4; break;
        case GLFW_KEY_5: sel = 5; break;

        case GLFW_KEY_DOWN: if (ma > 0) {
            ma = ma - 100;
        }
                          break;
        case GLFW_KEY_UP: ma = ma + 100; break;


        case GLFW_KEY_RIGHT: {
            if (cnt < 36 && cnt > 0)
                cnt++;
        }
                           break;
        case GLFW_KEY_LEFT: {
            if (cnt <= 36 && cnt > 1)
                cnt--;
        }
                          break;
        }
    }
}