#include "glSetup.h"

#ifdef _WIN32
#define _USE_MATH_DEFINES // To include the definition of M_PI in math.h
#endif

#include <glm/glm.hpp> //opengl mathmatics
#include <glm/gtc/type_ptr.hpp> //value_ptr()
using namespace glm;

#include <iostream>
#include <fstream>

using namespace std;

void init();

void render(GLFWwindow* window);
void keyboard(GLFWwindow* window, int key, int code, int action, int mods);


//Camera configuation
vec3 eye(3, 3, 3);
vec3 center(0, 0, 0);
vec3 up(0, 1, 0);

//Light configuration
vec4 light(5.0, 5.0, 0.0, 1); // light position

//global coordinate frame
float AXIS_LENGTH = 1.75;
float AXIS_LINE_WIDTH = 2;

//Colors
GLfloat bgColor[4] = { 1,1,1,1 };



//Paly configuration
bool pause = true;
float timeStep = 1.0f / 120;//120fps
float period = 8.0;
float theta = 0;


//Drawing parameters
bool depthTest = true;
bool polygonFill = false;

int main(int argc, char* argv[])
{
    //FPS control: vsync should be 0 for precise time stepping
    vsync = 0; // 0 for immediate mode (Tearing possible)

    //Initialize the OpenGL system
    GLFWwindow* window = initializeOpenGL(argc, argv, bgColor);
    if (window == NULL)   return -1;

    //Callbacks
    glfwSetKeyCallback(window, keyboard);

    //Normal vectors are normalized after transformation.
    glEnable(GL_NORMALIZE);

    // Turn off back face culling for cylinder
    glDisable(GL_CULL_FACE);

    //viewport and perspective setting
    reshape(window, windowW, windowH);

    //Initialization - Main loop - Finalization
    //
    init();

    //Main loop
    float previous = (float)glfwGetTime();
    float elapsed = 0;
    while (!glfwWindowShouldClose(window))
    {
        glfwPollEvents(); //Events

        float now = (float)glfwGetTime();
        float delta = now - previous;
        previous = now;

        elapsed += delta;

        if (elapsed > timeStep)
        {
            if (!pause)
            {
                theta += float(2.0 * M_PI) / period * elapsed;
            }
            elapsed = 0;
        }
        render(window);
        glfwSwapBuffers(window);
    }

    
    glfwDestroyWindow(window);
    glfwTerminate();

    return 0;
}


void init() {

    cout << endl;
    cout << "Keyboard input:   f for Overlay on/off" << endl;
    cout << endl;
    cout << "Keyboard input:   Left arrow key for Decrease the sweep" << endl;
    cout << "Keyboard input:   Right arrow key for Increase the sweep" << endl;
}


void setupLight() {
    //glEnable(GL_LIGHTING);
    //glEnable(GL_LIGHT0);
    
    GLfloat ambient[4] = { 0.1f,0.1f ,0.1f ,0.1f };
    GLfloat diffise[4] = { 1.0f,1.0f ,1.0f ,1.0f };
    GLfloat specular[4] = { 1.0f,1.0f ,1.0f ,1.0f };

    glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, diffise);
    glLightfv(GL_LIGHT0, GL_SPECULAR, specular);
    glLightfv(GL_LIGHT0, GL_POSITION, value_ptr(light));

    glLightModeli(GL_LIGHT_MODEL_TWO_SIDE, GL_TRUE);
}


void setupMaterial() {
    // Material 
    GLfloat mat_ambient[4] = { 0.1f, 0.1f, 0.1f, 1.0f };
    GLfloat mat_specular[4] = { 0.5f, 0.5f, 0.5f, 1.0f };
    GLfloat mat_shininess = 128;
    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, mat_ambient);
    glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, mat_specular);
    glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, mat_shininess);
}

void setDiffuseColor(const vec3& color) {
    GLfloat mat_diffuse[4] = { color[0],color[1] ,color[2] ,1 };
    glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, mat_diffuse);
}


int cnt = 1;
glm::vec3* vertex = NULL;
glm::vec3* vnormal = NULL;
glm::vec3* mid = NULL;

void drawTourus() {
    setDiffuseColor(vec3(0, 0, 0));
    glPointSize(3 * dpiScaling);

  
    float PI = M_PI;

    float theata1 = 2 * PI / 18;
    float theata2 = 2 * PI / 36;

    vertex = new glm::vec3[36 * 18];
    for (int i = 0; i < 36 * 18; i++) {
        vertex[i] = vec3(0.2, 0.2, 0);
    }

    vnormal = new glm::vec3[36 * 18];
    for (int i = 0; i < 36 * 18; i++) {
        vnormal[i] = vec3(0, 0, 0);
    }
    for (int i = 0; i < 18; i++) {
        float c = cos(theata1);
        float s = sin(theata1);
        glm::mat4 T(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0.5, 0.5, 0, 1);
        glm::vec4 temp(vertex[i].x, vertex[i].y, vertex[i].z, 1);
        if (i < 17) {
            glm::mat3 R(c, s, 0, -s, c, 0, 0, 0, 1);
            vertex[i + 1] = R * vertex[i];
            temp = T * temp;
            vertex[i].x = temp.x;
            vertex[i].y = temp.y;
            vertex[i].z = temp.z;
        }
        else {   
            temp = T * temp;
            vertex[i].x = temp.x;
            vertex[i].y = temp.y;
            vertex[i].z = temp.z;
        }
   }
    for (int i = 1; i < 36; i++) {
        float c = cos(theata2);
        float s = sin(theata2);
        glm::mat3 R(c, 0, -s, 0, 1, 0, s, 0, c);
        for (int j = 0; j < 18; j++) {
            vertex[18 * i + j] = R * vertex[18 * (i - 1) + j];
        }
    }

   
    for (int i = 0; i < 36; i++) {
        for (int j = 0; j < 18; j++) {
            int p1 = 18 * (i % 36) + (j % 18);
            int p2 = 18 * (i % 36) + ((j + 1) % 18);
            int p3 = 18 * ((i + 1) % 36) + (j % 18);
            vnormal[p1] = cross(vertex[p2] - vertex[p1], vertex[p3] - vertex[p1]);
          
        }
    }

    mid = new glm::vec3[36 * 18];

    for (int i = 0; i < 36; i++) {
        for (int j = 0; j < 18; j++) {
            mid[18 * i + j].x = (vertex[18 * (i % 36) + (j % 18)].x + vertex[18 * (i % 36) + ((j + 1) % 18)].x + vertex[18 * ((i + 1) % 36) + ((j + 1) % 18)].x + vertex[18 * ((i + 1) % 36) + (j % 18)].x) / 4.0f;
            mid[18 * i + j].y = (vertex[18 * (i % 36) + (j % 18)].y + vertex[18 * (i % 36) + ((j + 1) % 18)].y + vertex[18 * ((i + 1) % 36) + ((j + 1) % 18)].y + vertex[18 * ((i + 1) % 36) + (j % 18)].y) / 4.0f;
            mid[18 * i + j].z = (vertex[18 * (i % 36) + (j % 18)].z + vertex[18 * (i % 36) + ((j + 1) % 18)].z + vertex[18 * ((i + 1) % 36) + ((j + 1) % 18)].z + vertex[18 * ((i + 1) % 36) + (j % 18)].z) / 4.0f;
        }
    }
    
    for (int i = 0; i < cnt; i++) {
        for (int j = 0; j < 18; j++) {
            glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
            glBegin(GL_QUADS);

            glColor3f(0.0, 0.0, 0.0);
            glVertex3f(vertex[18 * (i % 36) + (j % 18)].x, vertex[18 * (i % 36) + (j % 18)].y, vertex[18 * (i % 36) + (j % 18)].z);
            glColor3f(0.0, 0.0, 0.0);
            glVertex3f(vertex[18 * (i % 36) + ((j + 1) % 18)].x, vertex[18 * (i % 36) + ((j + 1) % 18)].y, vertex[18 * (i % 36) + ((j + 1) % 18)].z);
            glColor3f(0.0, 0.0, 0.0);
            glVertex3f(vertex[18 * ((i + 1) % 36) + ((j + 1) % 18)].x, vertex[18 * ((i + 1) % 36) + ((j + 1) % 18)].y, vertex[18 * ((i + 1) % 36) + ((j + 1) % 18)].z);
            glColor3f(0.0, 0.0, 0.0);
            glVertex3f(vertex[18 * ((i + 1) % 36) + (j % 18)].x, vertex[18 * ((i + 1) % 36) + (j % 18)].y, vertex[18 * ((i + 1) % 36) + (j % 18)].z);
            glEnd();

            if (polygonFill) {
                glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
                glPolygonOffset(1.0f, 1.0f);

                glBegin(GL_QUADS);

                if (dot(vnormal[18 * i + j], eye - mid[18 * i + j]) < 0) {
                    glColor3f(0.0, 0.0, 1.0);
                    glVertex3f(vertex[18 * (i % 36) + (j % 18)].x, vertex[18 * (i % 36) + (j % 18)].y, vertex[18 * (i % 36) + (j % 18)].z);
                    glColor3f(0.0, 0.0, 1.0);
                    glVertex3f(vertex[18 * (i % 36) + ((j + 1) % 18)].x, vertex[18 * (i % 36) + ((j + 1) % 18)].y, vertex[18 * (i % 36) + ((j + 1) % 18)].z);
                    glColor3f(0.0, 0.0, 1.0);
                    glVertex3f(vertex[18 * ((i + 1) % 36) + ((j + 1) % 18)].x, vertex[18 * ((i + 1) % 36) + ((j + 1) % 18)].y, vertex[18 * ((i + 1) % 36) + ((j + 1) % 18)].z);
                    glColor3f(0.0, 0.0, 1.0);
                    glVertex3f(vertex[18 * ((i + 1) % 36) + (j % 18)].x, vertex[18 * ((i + 1) % 36) + (j % 18)].y, vertex[18 * ((i + 1) % 36) + (j % 18)].z);

                }
                else {
                    glColor3f(1.0, 0.0, 0.0);
                    glVertex3f(vertex[18 * (i % 36) + (j % 18)].x, vertex[18 * (i % 36) + (j % 18)].y, vertex[18 * (i % 36) + (j % 18)].z);
                    glColor3f(1.0, 0.0, 0.0);
                    glVertex3f(vertex[18 * (i % 36) + ((j + 1) % 18)].x, vertex[18 * (i % 36) + ((j + 1) % 18)].y, vertex[18 * (i % 36) + ((j + 1) % 18)].z);
                    glColor3f(1.0, 0.0, 0.0);
                    glVertex3f(vertex[18 * ((i + 1) % 36) + ((j + 1) % 18)].x, vertex[18 * ((i + 1) % 36) + ((j + 1) % 18)].y, vertex[18 * ((i + 1) % 36) + ((j + 1) % 18)].z);
                    glColor3f(1.0, 0.0, 0.0);
                    glVertex3f(vertex[18 * ((i + 1) % 36) + (j % 18)].x, vertex[18 * ((i + 1) % 36) + (j % 18)].y, vertex[18 * ((i + 1) % 36) + (j % 18)].z);
                }
                glEnd();
            }
        }
    }
}
void render(GLFWwindow* window) {

    if (depthTest) glEnable(GL_DEPTH_TEST);
    else glDisable(GL_DEPTH_TEST);

    if (polygonFill) glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
    else glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

    glClearColor(bgColor[0], bgColor[1], bgColor[2], bgColor[3]);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    gluLookAt(eye[0], eye[1], eye[2], center[0], center[1], center[2], up[0], up[1], up[2]);

    glDisable(GL_LIGHTING);
    drawAxes(AXIS_LENGTH, AXIS_LINE_WIDTH * dpiScaling);

    setupLight();
    setupMaterial();
    glRotatef(degrees(theta), 0, 1, 0);

    drawTourus();
}

void keyboard(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (action == GLFW_PRESS || action == GLFW_REPEAT)
    {
        switch (key) {
        case GLFW_KEY_Q:
        case GLFW_KEY_ESCAPE:   glfwSetWindowShouldClose(window, GL_TRUE); break;
        
        case GLFW_KEY_F:   polygonFill = !polygonFill; break;

       case GLFW_KEY_RIGHT: {
           if (cnt < 36 && cnt > 0)
               cnt++;
        }
                           break;
        case GLFW_KEY_LEFT: {
            if (cnt <= 36 && cnt > 1)
                cnt--;
        }
                          break;
        }
    }
}