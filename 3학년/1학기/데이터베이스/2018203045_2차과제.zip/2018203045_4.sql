insert into student
	select ID,name,dept_name,0
	from instructor
	where ID <="60000"
