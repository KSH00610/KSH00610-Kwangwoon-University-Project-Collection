select distinct(ID), name, dept_name
from instructor natural join teaches
where course_id like "%CS-1%"
