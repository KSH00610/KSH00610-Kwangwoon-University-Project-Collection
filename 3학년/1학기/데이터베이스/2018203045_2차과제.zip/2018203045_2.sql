select *
from course
where course_id like "%CS-1%"
