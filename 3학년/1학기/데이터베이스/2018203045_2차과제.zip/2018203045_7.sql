update instructor
set salary = (select case
			  	when count(teaches.ID) = 0 then 30000
			  	else count(teaches.ID)*50000
			  end
			 from teaches
			where instructor.ID=teaches.ID
			)