update student
set tot_cred =(select case
		 when sum(C.credits)is not null then sum(C.credits)
		else 0
		end
		from takes as T, course as C
		where T.course_id = C.course_id and student.ID=T.ID and T.grade <>'F' and T.grade is not null )
