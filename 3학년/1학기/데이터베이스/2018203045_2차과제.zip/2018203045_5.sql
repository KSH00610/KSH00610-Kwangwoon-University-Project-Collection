delete from student
where ID in (select ID
			from instructor) and
		name in (select name
				 from instructor)
