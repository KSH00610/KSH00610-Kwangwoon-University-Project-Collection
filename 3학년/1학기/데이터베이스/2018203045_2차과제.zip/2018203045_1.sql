select max(num_of_students), min(num_of_students)
from(
	select count(course_id) as num_of_students
	from takes
	group by course_id)
where num_of_students >0
