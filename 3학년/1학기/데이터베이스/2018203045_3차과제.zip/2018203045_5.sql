select name,occupation
from people_main,(select distinct ID1, count(ID1) as cnt
					from people_friends
					group by ID1)
where ID = ID1 and cnt >=3