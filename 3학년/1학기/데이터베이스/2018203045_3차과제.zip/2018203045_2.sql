select distinct name, title 
from actors natural left outer join actor_role natural left outer join movies
where title is null