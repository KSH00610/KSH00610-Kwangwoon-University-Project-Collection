select distinct T1.name, T1.ID, T2.ID, T2.name
from (	select distinct *
		from people_main, people_likes
		where ID = ID1 and (ID1, ID2) not in (select ID1, ID2
					from people_main,people_friends
					where ID = ID1)
		order by ID, ID2) as T1,
	(	select distinct *
		from people_main, people_likes
		where ID = ID1 and (ID1, ID2) not in (select ID1, ID2
					from people_main,people_friends
					where ID = ID1)
		order by ID, ID2) as T2
where T1.ID2 = T2.ID