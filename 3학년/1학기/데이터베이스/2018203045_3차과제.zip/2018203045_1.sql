select distinct title, count(movies.MID)
from movies, actor_role
where movies.MID = actor_role.MID and actor_role.AID = "00007"
group by movies.MID