select distinct T1.name, T1.birth_year
from (	select *
		from people_main, people_likes
		where ID = ID2) as T1,
	(	select *
		from people_main, people_likes
		where ID = ID1) as T2
where T1.ID1 = T2.ID and  T1.birth_year <T2.birth_year and T1.ID1 = T2.ID1 and T1.ID2 = T2.ID2