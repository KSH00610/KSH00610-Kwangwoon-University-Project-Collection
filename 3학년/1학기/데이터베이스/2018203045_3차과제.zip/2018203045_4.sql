select distinct count(ID), name
from people_main, (select distinct *
					from people_likes as A, people_likes as B
					where A.ID1 = B.ID2 and A.ID2= B.ID1) 
where people_main.ID = ID1
group by ID
order by count(ID) desc