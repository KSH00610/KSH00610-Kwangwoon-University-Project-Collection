select T.ID, sum(C.credits)
from takes as T, course as C
where T.course_id = C.course_id
group by T.ID
