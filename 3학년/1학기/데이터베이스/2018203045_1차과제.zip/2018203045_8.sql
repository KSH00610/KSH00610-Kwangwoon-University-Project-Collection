select ID, name
from instructor
except
select distinct I.ID,I.name
from instructor as I, teaches as T
where I.ID = T.ID