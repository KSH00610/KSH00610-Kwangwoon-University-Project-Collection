select sum(credits)
from takes as T, course as C
where T.ID=45678 and T.course_id=C.course_id
