SELECT name
FROM instructor
WHERE dept_name="Finance"
