select distinct S.name
from takes as T, course as C, student as S
where C.dept_name = 'Comp. Sci.' and T.course_id = C.course_id and T.ID=S.ID 
