select title
from course
where dept_name="Biology" and credits=4 
