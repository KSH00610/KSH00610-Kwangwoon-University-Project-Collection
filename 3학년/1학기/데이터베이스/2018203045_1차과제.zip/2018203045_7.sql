select distinct ID from instructor
except
select distinct ID from teaches
