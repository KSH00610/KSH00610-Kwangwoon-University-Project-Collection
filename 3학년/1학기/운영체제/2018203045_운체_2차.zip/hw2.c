#include <stdio.h>
#include <stdlib.h>
#include "disk.h"
#include "hw1.h"
#include "hw2.h"
#include <string.h>


FileDescTable* pFileDescTable;
FileSysInfo* pFileSysInfo;

int OpenFile(const char* name, OpenFlag flag)
{
    Inode* pInode;
    int inode=0;
    inode=GetFreeInodeNum();
    if(flag == OPEN_FLAG_CREATE){
        char *buf=(char*)malloc(sizeof(name));
        memcpy(buf,name,sizeof(name));
        GetInode(0,pInode);
        char *temp=strtok(buf,"/");
        while(temp != NULL){
           
        }
    }
}


int WriteFile(int fileDesc, char* pBuffer, int length)
{
    int block_num=0;
    File* file = (File*)pFileDescTable;
    int inode_num=file[fileDesc].inodeNum;
    Inode* pnode=(Inode*)malloc(sizeof(Inode));
    GetInode(inode_num,pnode);
    char*buf=(char*)malloc(BLOCK_SIZE);
    int * indirect =(int*)malloc(BLOCK_SIZE);
    int write=0;

    if(file[fileDesc].fileOffset + length <= (NUM_OF_DIRECT_BLOCK_PTR + BLOCK_SIZE/4)*BLOCK_SIZE){
        int sz=file[fileDesc].fileOffset % BLOCK_SIZE;
        int free = BLOCK_SIZE - file[fileDesc].fileOffset % BLOCK_SIZE;
        int last=(int)(file[fileDesc].fileOffset / BLOCK_SIZE);

        while(write < length){
            if(last < NUM_OF_DIRECT_BLOCK_PTR){
                if(pnode->dirBlockPtr[last] != 0){
                    block_num = pnode->dirBlockPtr[last];
                }
                else{
                    block_num=GetFreeBlockNum();
                }

                if(write==0){
                    DevReadBlock(block_num,buf);
                    memcpy(buf+sz,pBuffer,free);
                    DevWriteBlock(block_num,buf);
                }
                else{
                    memcpy(buf, pBuffer, BLOCK_SIZE);
                    DevWriteBlock(block_num,buf);
                    pnode->dirBlockPtr[last]=block_num;
                    PutInode(inode_num,pnode);
                    SetBlockBytemap(block_num);
                }

            }
        }

    }
    PutInode(inode_num,pnode);
    DevReadBlock(FILESYS_INFO_BLOCK,buf);
    FileSysInfo* info=(FileSysInfo*)buf;
    //info->numAllocBlocks
}


int ReadFile(int fileDesc, char* pBuffer, int length)
{

}

int CloseFile(int fileDesc)
{

}

int RemoveFile(char* name)
{

}


int MakeDirectory(char* name)
{
    int block_num = GetFreeBlockNum();
    int inode_num = GetFreeInodeNum();
    Inode* pnode = (Inode*)malloc(32);
    GetInode(0,pnode);
    DirEntry* dir = (DirEntry*)pnode;
    char* buf1 = (char*)malloc(sizeof(name));
    memcpy(buf1, name,sizeof(name));
    int prenum=1;
    int nextnum=0;
    int diridx=0;
    char*temp = (char*)malloc(sizeof(name));
    for(int i=1; i<strlen(name); i++){
        if(name[i] == "/"){
            strncpy(temp,buf1+prenum, nextnum);
            for(int j=0; j<16; j++){
                if(strcmp(*(dir+j)->name, temp) ==0){
                    GetInode(dir[j].inodeNum, pnode);

                }
                if(dir[j].name == INVALID_ENTRY && strcmp(*(dir+j)->name, temp)!=0){
                    dir[j].inodeNum=j;
                    strcpy(dir[j].name, temp);
                    DevWriteBlock(block_num, (char*)dir);
                }
            }
            prenum=nextnum+1;
            nextnum=0;
        }
        nextnum++;
       
    }
    GetInode(inode_num, pnode);
    pnode->dirBlockPtr[0]=block_num;
    PutInode(inode_num,pnode);
    SetBlockBytemap(block_num);
    SetInodeBytemap(inode_num);
    char *buf2 = (char*)malloc(BLOCK_SIZE);
    DevReadBlock(FILESYS_INFO_BLOCK,buf2);
    pFileSysInfo = (FileSysInfo*)buf2;
    (*pFileSysInfo).numAllocBlocks++;
    (*pFileSysInfo).numFreeBlocks--;
    (*pFileSysInfo).numAllocInodes++;
    DevWriteBlock(FILESYS_INFO_BLOCK,buf2);
    free(temp);
    free(buf1);
    free(buf2);
    free(pnode);
    return 0;
}


int RemoveDirectory(char* name)
{
    char* buf = (char*)malloc(sizeof(name));
    memcpy(buf,name,sizeof(name));
    DirEntry* dir = (DirEntry*)malloc(BLOCK_SIZE);
   
}


void CreateFileSystem(void)
{
    FileSysInit();
    int block_num=GetFreeBlockNum();
    int inode_num=GetFreeInodeNum();
    char *buf = (char*)malloc(BLOCK_SIZE);
    DevReadBlock(block_num,buf);
    DirEntry(* dirEntry)[16] =(DirEntry(*)[16])buf;
    dirEntry[0]->inodeNum=0;
    strcpy(dirEntry[0]->name,".");
    DevWriteBlock(block_num,buf);
    free(buf);
    char *buf1 = (char*)malloc(BLOCK_SIZE);
    DevReadBlock(FILESYS_INFO_BLOCK,buf1);
    pFileSysInfo = (FileSysInfo*)buf1;
    (*pFileSysInfo).blocks=512;
    (*pFileSysInfo).rootInodeNum=0;
    (*pFileSysInfo).diskCapacity=262144;
    (*pFileSysInfo).numAllocBlocks=0;
    (*pFileSysInfo).numFreeBlocks=501;
    (*pFileSysInfo).numAllocInodes=0;
    (*pFileSysInfo).blockBytemapBlock=BLOCK_BYTEMAP_BLOCK_NUM;
    (*pFileSysInfo).inodeBytemapBlock=INODE_BYTEMAP_BLOCK_NUM;
    (*pFileSysInfo).inodeListBlock=INODELIST_BLOCK_FIRST;
    (*pFileSysInfo).dataRegionBlock=11;
    (*pFileSysInfo).numAllocBlocks++;
    (*pFileSysInfo).numFreeBlocks--;
    (*pFileSysInfo).numAllocInodes++;
    DevWriteBlock(FILESYS_INFO_BLOCK,buf1);
    free(buf1);
    SetBlockBytemap(block_num);
    SetInodeBytemap(inode_num);
    Inode* pnode = (Inode*)malloc(32);
    GetInode(0,pnode);
    pnode->dirBlockPtr[0]=11;
    pnode->size = 512;
    pnode->type=FILE_TYPE_DIR;
    PutInode(0,pnode);
}
void OpenFileSystem(void)
{
    DevOpenDisk();
}

void CloseFileSystem(void)
{
    DevCloseDisk();
}

Directory* OpenDirectory(char* name)
{
    Inode* pnode = (Inode*)malloc(32);
    GetInode(0,pnode);
    DirEntry* dir = (DirEntry*)pnode;
    char* buf1 = (char*)malloc(sizeof(name));
    memcpy(buf1, name,sizeof(name));
    int prenum=1;
    int nextnum=0;
    int diridx=0;
   
    char*temp = (char*)malloc(sizeof(name));
     for(int i=1; i<strlen(name); i++){
        if(name[i] == "/"){
            strncpy(temp,buf1+prenum, nextnum);
            for(int j=0; j<16; j++){
                if(strcmp(*(dir+j)->name, temp) ==0){
                    GetInode(dir[j].inodeNum, pnode);

                }
            }
            prenum=nextnum+1;
            nextnum=0;
        }
        nextnum++;
    }
    Directory *direct = (Directory*)pnode;
    return direct;
   
}


FileInfo* ReadDirectory(Directory* pDir)
{
   
}

int CloseDirectory(Directory* pDir)
{

}
