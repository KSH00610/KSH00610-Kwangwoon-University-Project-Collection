#include <stdio.h>
#include <stdlib.h>
#include "disk.h"
#include "fs.h"
#include <string.h>

void FileSysInit(void){
    DevCreateDisk();
    DevOpenDisk();
    char *buf = (char*)malloc(BLOCK_SIZE);
    memset(buf,0,BLOCK_SIZE);
    for(int i=0; i<=6; i++){
        DevWriteBlock(i,buf);
    }
    free(buf);
}

void SetInodeBytemap(int inodeno)
{
    char *buf = (char*)malloc(BLOCK_SIZE);
    DevReadBlock(INODE_BYTEMAP_BLOCK_NUM,buf);
    buf[inodeno]=1;
    DevWriteBlock(INODE_BYTEMAP_BLOCK_NUM,buf);
    free(buf);
}


void ResetInodeBytemap(int inodeno)
{
    char *buf = (char*)malloc(BLOCK_SIZE);
    DevReadBlock(INODE_BYTEMAP_BLOCK_NUM,buf);
    buf[inodeno]=0;
    DevWriteBlock(INODE_BYTEMAP_BLOCK_NUM,buf);
    free(buf);
}


void SetBlockBytemap(int blkno)
{
    char *buf = (char*)malloc(BLOCK_SIZE);
    DevReadBlock(BLOCK_BYTEMAP_BLOCK_NUM,buf);
    buf[blkno]=1;
    DevWriteBlock(BLOCK_BYTEMAP_BLOCK_NUM,buf);
    free(buf);
}


void ResetBlockBytemap(int blkno)
{
    char *buf = (char*)malloc(BLOCK_SIZE);
    DevReadBlock(BLOCK_BYTEMAP_BLOCK_NUM,buf);
    buf[blkno]=0;
    DevWriteBlock(BLOCK_BYTEMAP_BLOCK_NUM,buf);
    free(buf);
}


void PutInode(int inodeno, Inode* pInode)
{
    char *buf = (char*)malloc(BLOCK_SIZE);
    int block_num=inodeno/16+3;
    int inode_offset=inodeno%16;
    DevReadBlock(block_num,buf);
    memcpy(pInode,buf+inode_offset*32,32);
    DevWriteBlock(block_num,buf);
    free(buf);
}


void GetInode(int inodeno, Inode* pInode)
{
   char *buf = (char*)malloc(BLOCK_SIZE);
   int block_num=inodeno/16+3;
   int inode_offset=inodeno%16;
   DevReadBlock(block_num,buf);
   memcpy(pInode,buf+inode_offset*32,32);
   free(buf);
}


int GetFreeInodeNum(void)
{
    char *buf = (char*)malloc(BLOCK_SIZE);
    int answer=0;
    DevReadBlock(INODE_BYTEMAP_BLOCK_NUM ,buf);
    for(int i=0; i<BLOCK_SIZE; i++){
        if(buf[i] == 1){
            continue;
        }
        else{
            answer=i;
            break;
        }
    }
    free(buf);
    return answer;
}


int GetFreeBlockNum(void)
{
    char *buf = (char*)malloc(BLOCK_SIZE);
    int answer=0;
    DevReadBlock(BLOCK_BYTEMAP_BLOCK_NUM,buf);
    for(int i=0; i<BLOCK_SIZE; i++){
        if(buf[i]==1){
            continue;
        }
        else{
            answer=i;
            break;
        }
    }
    free(buf);
    return answer;
}

void PutIndirectBlockEntry(int blkno, int index, int number)
{
    char *buf = (char*)malloc(BLOCK_SIZE);
    DevReadBlock(blkno,buf);
    buf[index*4]=number;
    DevWriteBlock(blkno,buf);
    free(buf);

}

int GetIndirectBlockEntry(int blkno, int index)
{
    char *buf = (char*)malloc(BLOCK_SIZE);
    int answer=0;
    DevReadBlock(blkno,buf);
    answer=buf[index*4];
    free(buf);
    return answer;
}

void RemoveIndirectBlockEntry(int blkno, int index)
{
    char *buf = (char*)malloc(BLOCK_SIZE);
    DevReadBlock(blkno,buf);
    buf[index*4]=INVALID_ENTRY;
    DevWriteBlock(blkno,buf);
    free(buf);
}

void PutDirEntry(int blkno, int index, DirEntry* pEntry)
{
    char *buf = (char*)malloc(BLOCK_SIZE);
    DevReadBlock(blkno,buf);
    memcpy(buf+(blkno %16)*32,pEntry,32);
    //buf[index*32]= pEntry;
    DevWriteBlock(blkno,buf);
    free(buf);
}

int GetDirEntry(int blkno, int index, DirEntry* pEntry)
{
    if(index*32 > BLOCK_SIZE){
        return -1;
    }
    char *buf = (char*)malloc(BLOCK_SIZE);
    DevReadBlock(blkno,buf);
    memcpy(pEntry,buf+(blkno %16)*32,32);
    free(buf);
    return 1;
}

void RemoveDirEntry(int blkno, int index)
{
    char *buf = (char*)malloc(BLOCK_SIZE);
    DevReadBlock(blkno,buf);
    buf[index*32]=INVALID_ENTRY;
    DevWriteBlock(blkno,buf);
    free(buf);
}
