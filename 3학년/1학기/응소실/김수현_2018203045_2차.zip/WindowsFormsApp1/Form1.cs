﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }

        private void buttonFor_Click(object sender, EventArgs e)
        {
            textBoxResult.Text = string.Empty;
            StringBuilder sb = new StringBuilder();

            int iResult = 0;
            for (int j = 0; j < 10; j++)
            {
                iResult += j;
                sb.Append(string.Format("1에서 {0}까지 더하면 {1}\r\n", j, iResult));
            }
            textBoxResult.Text = sb.ToString();
        }

        private void buttonForeach_Click(object sender, EventArgs e)
        {
            textBoxResult.Text = string.Empty;
            StringBuilder sb = new StringBuilder();

            int i = 65;
            string[] strArray = { "Kim", "Lee", "Park", "Moon", "Cho", "Choi", "Oh" };
            foreach(string name in strArray)
            {
                sb.Append(String.Format("{0} 교수 강의는 {1}반 입니다.\r\n", name, (char)i++));

            }
            textBoxResult.Text = sb.ToString().Trim();
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxResult.Text = string.Empty;
        }
    }
}
