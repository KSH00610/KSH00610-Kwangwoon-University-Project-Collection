﻿namespace WindowsFormsApp1
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.menuStrip3 = new System.Windows.Forms.MenuStrip();
            this.c윈도우폼예제ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.루프예제ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.판단예제ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.간단한어플ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.초간단계산기ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.로또계산기ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Location = new System.Drawing.Point(0, 52);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // menuStrip2
            // 
            this.menuStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.c윈도우폼예제ToolStripMenuItem,
            this.간단한어플ToolStripMenuItem});
            this.menuStrip2.Location = new System.Drawing.Point(0, 24);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Size = new System.Drawing.Size(800, 28);
            this.menuStrip2.TabIndex = 1;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // menuStrip3
            // 
            this.menuStrip3.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip3.Location = new System.Drawing.Point(0, 0);
            this.menuStrip3.Name = "menuStrip3";
            this.menuStrip3.Size = new System.Drawing.Size(800, 24);
            this.menuStrip3.TabIndex = 2;
            this.menuStrip3.Text = "menuStrip3";
            // 
            // c윈도우폼예제ToolStripMenuItem
            // 
            this.c윈도우폼예제ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.루프예제ToolStripMenuItem,
            this.판단예제ToolStripMenuItem});
            this.c윈도우폼예제ToolStripMenuItem.Name = "c윈도우폼예제ToolStripMenuItem";
            this.c윈도우폼예제ToolStripMenuItem.Size = new System.Drawing.Size(142, 24);
            this.c윈도우폼예제ToolStripMenuItem.Text = "C# 윈도우폼 예제";
            // 
            // 루프예제ToolStripMenuItem
            // 
            this.루프예제ToolStripMenuItem.Name = "루프예제ToolStripMenuItem";
            this.루프예제ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.루프예제ToolStripMenuItem.Text = "루프예제";
            this.루프예제ToolStripMenuItem.Click += new System.EventHandler(this.루프예제ToolStripMenuItem_Click);
            // 
            // 판단예제ToolStripMenuItem
            // 
            this.판단예제ToolStripMenuItem.Name = "판단예제ToolStripMenuItem";
            this.판단예제ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.판단예제ToolStripMenuItem.Text = "판단예제";
            this.판단예제ToolStripMenuItem.Click += new System.EventHandler(this.판단예제ToolStripMenuItem_Click);
            // 
            // 간단한어플ToolStripMenuItem
            // 
            this.간단한어플ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.초간단계산기ToolStripMenuItem,
            this.로또계산기ToolStripMenuItem});
            this.간단한어플ToolStripMenuItem.Name = "간단한어플ToolStripMenuItem";
            this.간단한어플ToolStripMenuItem.Size = new System.Drawing.Size(103, 24);
            this.간단한어플ToolStripMenuItem.Text = "간단한 어플";
            // 
            // 초간단계산기ToolStripMenuItem
            // 
            this.초간단계산기ToolStripMenuItem.Name = "초간단계산기ToolStripMenuItem";
            this.초간단계산기ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.초간단계산기ToolStripMenuItem.Text = "초간단 계산기";
            this.초간단계산기ToolStripMenuItem.Click += new System.EventHandler(this.초간단계산기ToolStripMenuItem_Click);
            // 
            // 로또계산기ToolStripMenuItem
            // 
            this.로또계산기ToolStripMenuItem.Name = "로또계산기ToolStripMenuItem";
            this.로또계산기ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.로또계산기ToolStripMenuItem.Text = "로또 계산기";
            this.로또계산기ToolStripMenuItem.Click += new System.EventHandler(this.로또계산기ToolStripMenuItem_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.menuStrip2);
            this.Controls.Add(this.menuStrip3);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MainForm";
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem c윈도우폼예제ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 루프예제ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 판단예제ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 간단한어플ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 초간단계산기ToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip3;
        private System.Windows.Forms.ToolStripMenuItem 로또계산기ToolStripMenuItem;
    }
}