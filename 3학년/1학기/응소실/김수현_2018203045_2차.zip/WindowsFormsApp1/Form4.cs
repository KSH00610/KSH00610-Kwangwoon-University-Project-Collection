﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form4 : Form
    {
        Random random = new Random();//뽑은 번호와 당첨 번호에 사용하게 될 난수
        public int[] lot = new int[6];//뽑은 번호를 저장하게될 정수형 배열
        public int[] WinningLot = new int[6];//당첨 번호를 저장하게될 정수형 배열



        public Form4()
        {
            InitializeComponent();
        }

        private void SelectNumber_Click_1(object sender, EventArgs e)
        {
            int n;

            for (int i = 0; i < 6; i++)
            {
                lot[i] = -1;//뽑은 번호를 저장할 배열을 초기화
            }

            for (int i = 0; i < 6; i++)
            {
                while (true)
                {
                    n = random.Next(1, 46);//1~46까지의 난수 생성
                    if (!lot.Contains(n))//뽑은 난수가 배열 안에 포함되어있는지 확인
                    {
                        lot[i] = n;//뽑은 난수가 배열 안에 포함되어있지 않으면 추가
                        break;
                    }
                }
            }

            Array.Sort(lot);//오름차순으로 배열 정렬

            N1.Text = lot[0].ToString();
            N2.Text = lot[1].ToString();
            N3.Text = lot[2].ToString();
            N4.Text = lot[3].ToString();
            N5.Text = lot[4].ToString();
            N6.Text = lot[5].ToString();
            //각각의 뽑은 정수값을 Label에 저장

        }

        private void WinningResult_Click_1(object sender, EventArgs e)
        {
            // WinningResult 함수를 구현하는 코드를 작성하세요.

            int n;

            for (int i = 0; i < 6; i++)
            {
                WinningLot[i] = -1;//당첨 번호 저장할 배열 초기화
            }

            for (int i = 0; i < 6; i++)
            {
                while (true)
                {
                    n = random.Next(1, 46);//1~46까지의 난수 생성
                    if (!WinningLot.Contains(n))//뽑은 난수가 배열 안에 포함되어있는지 확인
                    {
                        WinningLot[i] = n;//뽑은 난수가 배열 안에 포함되어있지 않으면 추가
                        break;
                    }
                }
            }

            Array.Sort(WinningLot);//오름차순 정렬

            W1.Text = WinningLot[0].ToString();
            W2.Text = WinningLot[1].ToString();
            W3.Text = WinningLot[2].ToString();
            W4.Text = WinningLot[3].ToString();
            W5.Text = WinningLot[4].ToString();
            W6.Text = WinningLot[5].ToString();
            //각각의 뽑은 정수값을 Label에 저장
            int count = 0;//당첨된 것 갯수 카운트하기위한 변수
            for (int i = 0; i < WinningLot.Length; i++)
            {
                for (int j = 0; j < lot.Length; j++)
                {
                    if (WinningLot[i] == lot[j])//뽑은 번호와 당첨번호가 같을 시
                    {
                        count++;//카운트를 1 증가
                    }
                }
            }
            string a = String.Format("당첨된 번호 갯수는 {0} 개 입니다!", count.ToString());
            tboxResult.Text = a;
            //해당 문자열의 textbox에 저장

        }

        private void CloseButton_Click_1(object sender, EventArgs e)
        {
            Close();
        }
    }
}
