﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class NumResult : Form
    {
        public NumResult()
        {
            InitializeComponent();
        }

        private void Number1_ValueChanged(object sender, EventArgs e)
        {
          
        }

        private void NumberResult_Click(object sender, EventArgs e)
        {
            int number1 = Convert.ToInt32(Number1.Value.ToString());
            int number2 = Convert.ToInt32(Number2.Value.ToString());
            string select = arthimetic.Text;
            switch (select)
            {
                case "+":
                    result.Text = string.Format("결과: {0} {1} {2} = {3}", number1, select, number2, number1 + number2);
                    break;
                case "-":
                    result.Text = string.Format("결과: {0} {1} {2} = {3}", number1, select, number2, number1 - number2);
                    break;
                case "*":
                    result.Text = string.Format("결과: {0} {1} {2} = {3}", number1, select, number2, number1 * number2);
                    break;
                case "/":
                    result.Text = string.Format("결과: {0} {1} {2} = {3}", number1, select, number2, number1 / number2);
                    break;
                case "%":
                    result.Text = string.Format("결과: {0} {1} {2} = {3}", number1, select, number2, number1 % number2);
                    break;
            }

        }
    }
}
