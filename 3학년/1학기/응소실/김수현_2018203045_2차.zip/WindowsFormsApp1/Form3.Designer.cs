﻿namespace WindowsFormsApp1
{
    partial class NumResult
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Number1 = new System.Windows.Forms.NumericUpDown();
            this.Number2 = new System.Windows.Forms.NumericUpDown();
            this.result = new System.Windows.Forms.Label();
            this.arthimetic = new System.Windows.Forms.ComboBox();
            this.NumberResult = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.Number1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Number2)).BeginInit();
            this.SuspendLayout();
            // 
            // Number1
            // 
            this.Number1.Location = new System.Drawing.Point(63, 116);
            this.Number1.Name = "Number1";
            this.Number1.Size = new System.Drawing.Size(233, 25);
            this.Number1.TabIndex = 0;
            this.Number1.ValueChanged += new System.EventHandler(this.Number1_ValueChanged);
            // 
            // Number2
            // 
            this.Number2.Location = new System.Drawing.Point(63, 206);
            this.Number2.Name = "Number2";
            this.Number2.Size = new System.Drawing.Size(233, 25);
            this.Number2.TabIndex = 1;
            // 
            // result
            // 
            this.result.AutoSize = true;
            this.result.Location = new System.Drawing.Point(61, 294);
            this.result.Name = "result";
            this.result.Size = new System.Drawing.Size(45, 15);
            this.result.TabIndex = 2;
            this.result.Text = "label1";
            // 
            // arthimetic
            // 
            this.arthimetic.FormattingEnabled = true;
            this.arthimetic.Items.AddRange(new object[] {
            "+",
            "-",
            "*",
            "/",
            "%"});
            this.arthimetic.Location = new System.Drawing.Point(318, 163);
            this.arthimetic.Name = "arthimetic";
            this.arthimetic.Size = new System.Drawing.Size(186, 23);
            this.arthimetic.TabIndex = 3;
            // 
            // NumberResult
            // 
            this.NumberResult.Location = new System.Drawing.Point(554, 116);
            this.NumberResult.Name = "NumberResult";
            this.NumberResult.Size = new System.Drawing.Size(171, 69);
            this.NumberResult.TabIndex = 4;
            this.NumberResult.Text = "연산";
            this.NumberResult.UseVisualStyleBackColor = true;
            this.NumberResult.Click += new System.EventHandler(this.NumberResult_Click);
            // 
            // NumResult
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.NumberResult);
            this.Controls.Add(this.arthimetic);
            this.Controls.Add(this.result);
            this.Controls.Add(this.Number2);
            this.Controls.Add(this.Number1);
            this.Name = "NumResult";
            this.Text = "산연";
            ((System.ComponentModel.ISupportInitialize)(this.Number1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Number2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown Number1;
        private System.Windows.Forms.NumericUpDown Number2;
        private System.Windows.Forms.Label result;
        private System.Windows.Forms.ComboBox arthimetic;
        private System.Windows.Forms.Button NumberResult;
    }
}