﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonFor = new System.Windows.Forms.Button();
            this.textBoxResult = new System.Windows.Forms.TextBox();
            this.buttonForeach = new System.Windows.Forms.Button();
            this.buttonClear = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonFor
            // 
            this.buttonFor.Location = new System.Drawing.Point(503, 28);
            this.buttonFor.Name = "buttonFor";
            this.buttonFor.Size = new System.Drawing.Size(237, 97);
            this.buttonFor.TabIndex = 0;
            this.buttonFor.Text = "For문";
            this.buttonFor.UseVisualStyleBackColor = true;
            this.buttonFor.Click += new System.EventHandler(this.buttonFor_Click);
            // 
            // textBoxResult
            // 
            this.textBoxResult.Location = new System.Drawing.Point(58, 43);
            this.textBoxResult.Multiline = true;
            this.textBoxResult.Name = "textBoxResult";
            this.textBoxResult.Size = new System.Drawing.Size(264, 144);
            this.textBoxResult.TabIndex = 2;
            // 
            // buttonForeach
            // 
            this.buttonForeach.Location = new System.Drawing.Point(503, 159);
            this.buttonForeach.Name = "buttonForeach";
            this.buttonForeach.Size = new System.Drawing.Size(237, 102);
            this.buttonForeach.TabIndex = 3;
            this.buttonForeach.Text = "Foreach문";
            this.buttonForeach.UseVisualStyleBackColor = true;
            this.buttonForeach.Click += new System.EventHandler(this.buttonForeach_Click);
            // 
            // buttonClear
            // 
            this.buttonClear.Location = new System.Drawing.Point(503, 310);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(236, 92);
            this.buttonClear.TabIndex = 4;
            this.buttonClear.Text = "출력지우기";
            this.buttonClear.UseVisualStyleBackColor = true;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonClear);
            this.Controls.Add(this.buttonForeach);
            this.Controls.Add(this.textBoxResult);
            this.Controls.Add(this.buttonFor);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonFor;
        private System.Windows.Forms.TextBox textBoxResult;
        private System.Windows.Forms.Button buttonForeach;
        private System.Windows.Forms.Button buttonClear;
    }
}

