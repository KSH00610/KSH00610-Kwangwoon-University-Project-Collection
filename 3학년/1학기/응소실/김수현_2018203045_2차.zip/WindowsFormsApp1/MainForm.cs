﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void 루프예제ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new Form1().ShowDialog();  
        }

        private void 판단예제ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new Form2().ShowDialog();
        }

        private void 초간단계산기ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new NumResult().ShowDialog();  
        }

        private void 로또계산기ToolStripMenuItem_Click(object sender, EventArgs e)
        {
           new Form4().ShowDialog();
        }
    }
}
