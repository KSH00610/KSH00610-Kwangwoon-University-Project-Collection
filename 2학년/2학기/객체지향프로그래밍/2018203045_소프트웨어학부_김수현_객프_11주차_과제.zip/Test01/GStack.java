package Test01;
import java.util.Stack;

public class GStack <T>{
	private Object[] var;
	private int num;
	public <T> GStack(int num)
	{
		var=new Object[num];
		this.num=0;
	}
	public void push(T item)
	{
		if(num==var.length)
			return;
		var[num++]=item;
	}
	public T pop()
	{
		if(num==0)
			return null;
		num--;
		return (T)var[num];
		
	}
}
