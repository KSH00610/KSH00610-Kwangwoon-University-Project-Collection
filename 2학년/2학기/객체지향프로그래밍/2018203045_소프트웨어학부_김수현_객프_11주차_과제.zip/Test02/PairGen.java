package Test02;

public class PairGen <K,V>{
	private K var1;
	private V var2;
	
	public PairGen(K var1, V var2)
	{
		this.var1=var1;
		this.var2=var2;
	}
	public K getK()
	{
		return var1;
	}
	public V getV()
	{
		return var2;
	}
}
