package Test02;

public class CompareGen{
	public static <K,V> boolean compare(PairGen<K,V> p1, PairGen<K,V> p2)
	{
		return (p1.getK()==p2.getK() && p1.getV()==p2.getV());
	}
}
