package Test02;

public class Ex2 {

	public static void main(String[] args) {
		PairGen<String, Integer> p1 = new PairGen<>("Apple", 3);
		PairGen<String, Integer> p2 = new PairGen<>("Apple", 3);
		System.out.println(CompareGen.compare(p1, p2));

		PairGen<String, String> p3 = new PairGen<>("��ü����", "Java");
		PairGen<String, String> p4 = new PairGen<>("��ü����", "C++");
		System.out.println(CompareGen.compare(p3, p4));

	}

}
