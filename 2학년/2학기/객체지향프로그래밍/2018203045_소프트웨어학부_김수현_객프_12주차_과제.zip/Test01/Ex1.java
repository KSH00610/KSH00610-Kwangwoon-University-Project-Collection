package Test01;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Ex1 {
	public static void main(String[] args) {
		List<Person> list = new ArrayList<>();
		list.add(new Person("Yoon", 23));
		list.add(new Person("Hong", 53));
		list.add(new Person("Kim", 37));
		list.add(new Person("Park", 67));
		list.add(new Person("Lee", 15));
		Collections.sort(list);
		System.out.println("***���̼� ����***");
		for(Person p : list)
		{
			System.out.println(p);
		}
		Collections.sort(list,new PersonComparator());
		System.out.println("***�̸��� ����***");
		for(Person p : list)
		{
			System.out.println(p);
		}
		
	}
	
}
class Person implements Comparable<Person>{
	 String name;
	 int age;
	 public Person(String name, int age) {
		 this.name = name; 
		 this.age = age;
	 }
	 public String toString() {
		 return name + " : " + age; }
	@Override
	public int compareTo(Person o) {
		// TODO Auto-generated method stub
		return this.age-o.age;
	}
	
}

class PersonComparator implements Comparator<Person>
{

	@Override
	public int compare(Person o1, Person o2) {
		// TODO Auto-generated method stub
		return o1.name.compareTo(o2.name);
	}
	
}