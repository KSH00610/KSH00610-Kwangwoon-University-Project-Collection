package api.calc;

public class Calc {
	private int result=0;
	private int num1,num2;
	private char ch;
	
	public Calc() {
		
	}
	public void setValue(int num1, int num2, char ch) {
		this.num1=num1;
		this.num2=num2;
		this.ch=ch;
		if(ch == '+')
		{
			result=add();
		}
		else if(ch == '-')
		{
			result=sub();
		}
		else if(ch == '*')
		{
			result=mul();
		}
		else if(ch == '/')
		{
			result=div();
		}
		else
		{
			return;
		}
	}
	public void result() {
		if(ch == '+' || ch=='-' || ch=='*' || ch=='/') {
			System.out.println("result = "+result);

		}
		else {
			System.out.println("�߸��� �������Դϴ�.");
		}
	}
	public int add()
	{
		return num1+num2;
	}
	public int sub() {
		return num1-num2;
	}
	public int mul() {
		return num1*num2;
	}
	public int div() {
		return num1/num2;
	}
	
}
