package api.calc;

public class ex5 {

	public static void main(String[] args) {
		Calc c = new Calc();
		c.setValue(2, 5, '+');
		c.result();
		c.setValue(2, 5, '$');
		c.result();
		c.setValue(2, 5, '-');
		c.result();
		c.setValue(2, 5, '*');
		c.result();
		c.setValue(2, 5, '/');
		c.result();

	}

}
