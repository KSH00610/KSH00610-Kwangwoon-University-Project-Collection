package api.tv;

public class TV {
		private String name;
		private int year, inch;
		
		public TV(String name, int year, int inch) {
			this.name=name;
			this.year=year;
			this.inch=inch;
		}
		public void show() {
			System.out.println(name+"���� ���� "+year+"���� "+inch+"��ġ TV");
		}
}
