package api.rect;

public class Rectangle {
		private int x,y,width,height;
		
		public Rectangle(int x, int y, int width, int height) {
			this.x=x;
			this.y=y;
			this.width=width;
			this.height=height;
		}
		
		public int square() {
			return width*height;
		}
		
		public void show() {
			System.out.println("("+x+","+y+")���� ũ�Ⱑ "+width+"x"+height+"�� �簢��");
		}
		
		public boolean contains(Rectangle r) {
			if(r.x>=x && r.y>=y && (r.x+r.width)<(x+width) && (r.y+r.height)<(y+height)) {
				return true;
			}
			else {
				return false;
			}
		}
}
