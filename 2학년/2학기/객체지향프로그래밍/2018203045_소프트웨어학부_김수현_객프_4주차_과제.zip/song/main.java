package api.song;

public class main {

	public static void main(String[] args) {
		Song mysong = new Song("Dancing Queen", "ABBA", 1978, "������");
		mysong.show();

	}

}
