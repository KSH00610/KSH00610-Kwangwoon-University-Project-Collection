package api.circle;

public class ex4 {

	public static void main(String[] args) {
		Circle c1 = new Circle("Pizza", 0);
		Circle c2 = new Circle("donut", 0);
		Circle c3 = new Circle("hamburger", 0);
		c1.setRad(12);
		c2.setRad(-2);
		c3.setRad(7);
		c1.show();
		c2.show();
		c3.show();
		System.out.print("���� ū ������ ");
		if(c1.getArea()>c2.getArea())
		{
			if(c1.getArea()>c3.getArea())
			{
				System.out.println(c1.getName());
			}
			else
			{
				System.out.println(c3.getName());
			}
		}
		else
		{
			if(c2.getArea()>c3.getArea())
			{
				System.out.println(c2.getName());
			}
			else
			{
				System.out.println(c3.getName());
			}
		}

	}

}
