package api.circle;

public class Circle {
	private int radius;
	private double pi=3.14;
	private String name;
	
	public Circle(String name, int radius) {
		this.radius= radius;
		this.name=name;
	}
	
	public void setRad(int radius) {
		if(radius >=0)
		{
			this.radius=radius;
		}
	}
	public String getName() {
		return name;
	}
	public double getArea() {
		return radius*radius*pi;
	}
	public void show()
	{
		System.out.println(name+"����:"+getArea());
	}
}
