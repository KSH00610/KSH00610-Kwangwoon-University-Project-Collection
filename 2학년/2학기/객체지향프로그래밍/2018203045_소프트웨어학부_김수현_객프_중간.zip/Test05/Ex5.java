package Test05;

public class Ex5 {

	public static void main(String[] args) {
		String str = "123";
		System.out.println(str+"�� �����Դϱ�? "+isNumber(str));
		str = "1234x";
		System.out.println(str+"�� �����Դϱ�? "+isNumber(str));
	}
	public static boolean isNumber(String str)
	{
		for(int i=0 ;i<str.length(); i++)
		{
			if(isdigit(str.charAt(i)) == false)
				return false;
		}
		
		return true;
	}
	private static boolean isdigit(char charAt) {
		// TODO Auto-generated method stub
		return false;
	}

}
