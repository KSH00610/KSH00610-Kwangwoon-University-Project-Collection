package Test04;

public class Book {
	private String title;
	private int price;
	private int page;
	
	public Book(String title, int price, int page)
	{
		this.title=title;
		this.price=price;
		this.page=page;
	}
	public String getTitle()
	{
		return title;
	}
	public String show()
	{
		return title+" "+price+"�� "+page+"������";
	}
}
