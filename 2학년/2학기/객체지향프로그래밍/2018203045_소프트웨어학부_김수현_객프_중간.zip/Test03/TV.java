package Test03;

public class TV {
	int size;
	public TV(int size)
	{
		this.size=size;
	}
	
	protected int getSize() {
		return size;
	}
	protected void setSize(int size)
	{
		this.size=size;
	}
}
