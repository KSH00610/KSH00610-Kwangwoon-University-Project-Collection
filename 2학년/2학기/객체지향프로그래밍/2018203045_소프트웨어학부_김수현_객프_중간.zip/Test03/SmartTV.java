package Test03;

public class SmartTV extends TV{
	String ipAddr;
	public SmartTV(int size, String ipAddr) {
		super(size);
		this.ipAddr = ipAddr;
	}
	String getIpAddr () { return ipAddr; }
	void setIpAddr (String ipAddr)
	{ this. ipAddr = ipAddr; }
}
