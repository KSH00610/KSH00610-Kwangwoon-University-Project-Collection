package Test03;

public class WideTV extends TV{
	boolean videoIn;
	public WideTV(int size, boolean videoIn) {
		super(size);
		this.videoIn = videoIn;
	}
	boolean getVideoIn() { return videoIn; }
	void setVideoIn(boolean videoIn)
	{ this.videoIn = videoIn; }

}
