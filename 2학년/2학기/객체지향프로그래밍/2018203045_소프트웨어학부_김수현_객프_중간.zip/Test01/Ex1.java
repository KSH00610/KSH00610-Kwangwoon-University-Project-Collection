package Test01;

import java.util.Scanner;

public class Ex1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("�� ���� ���� �Է� : ");
		int num1=sc.nextInt();
		int num2=sc.nextInt();
		System.out.print(num1+"�� "+num2+"�� = ");
		int result=1;
		for(int i=1; i<=num2; i++)
		{
			result*=num1;
		}
		System.out.println(result);

	}

}
