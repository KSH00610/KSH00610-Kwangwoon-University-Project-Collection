package Test02;

public class Ex2 {

	public static void main(String[] args) {
		int[] A = { 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3 };
		int[] B = { 3, 2, 1, -1 };
		int[] C = { 5, 3, 2, 1, -3 };
		int[] R = ArrayUtil.calc(A, B, C);
		System.out.print("A - (B U C) = { " + R[0]);
		for (int i = 1; i < R.length; i++)
			System.out.print(", " + R[i]);
		System.out.println(" }");

	}

}
