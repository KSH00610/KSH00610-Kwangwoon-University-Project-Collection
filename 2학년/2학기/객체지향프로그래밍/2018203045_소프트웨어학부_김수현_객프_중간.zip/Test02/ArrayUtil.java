package Test02;

public class ArrayUtil {
	public ArrayUtil()
	{
		
	}
	public static int[] calc(int[] a, int[] b, int[] c)
	{
		int[] result = new int[100];
		int[] finsh= new int[5];
		int num=0;
		int fnum=0;
		int cnt=0;
		for(int i=0; i<b.length; i++)
		{
			result[num]=b[i];
			num++;
		}
		for(int i=0; i<c.length; i++)
		{
			for(int j=0; j<num; j++)
			{
				if(c[i]==result[j])
				{
					cnt++;
				}
			}
			if(cnt==0)
			{
				result[num]=c[i];
				num++;
			}
			cnt=0;
		}
		cnt=0;
		for(int i=0;i <a.length; i++)
		{
			for(int j=0; j<num; j++)
			{
				if(a[i]==result[j])
				{
					cnt++;
				}
			}
			if(cnt==0)
			{
				finsh[fnum]=a[i];
				fnum++;
			}
			cnt=0;
		}
		return finsh;
	}
}
