package Test03;
import java.util.Arrays;

public class Circle implements Comparable{
	private String name;
	private int radius;
	private static double PI=3.14;
	
	public Circle(String name, int radius)
	{
		this.name=name;
		this.radius=radius;
	}
	
	@Override
	public int compareTo(Object o)
	{
		Circle c=(Circle)o;
		if(this.radius>c.radius)
		{
			return 1;
		}
		else if(this.radius<c.radius)
		{
			return -1;
		}
		else
		{
			return 0;
		}
	}
	
	public String toString()
	{
		return name+" "+radius*radius*PI;
	}
}
