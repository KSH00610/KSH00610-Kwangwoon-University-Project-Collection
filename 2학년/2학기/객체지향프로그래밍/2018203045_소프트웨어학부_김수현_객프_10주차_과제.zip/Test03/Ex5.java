package Test03;
import java.util.Arrays;
public class Ex5 {

	public static void main(String[] args) {
		Circle[] c = { new Circle("Cup", 3),
				new Circle("Apple", 4),
				new Circle("Doughnut", 5),
				new Circle("Pizza", 7),
				new Circle("Ball", 2) };
		
		Arrays.sort(c);
		for(Circle o : c)
		{
			System.out.println(o);
		}
		int idx=Arrays.binarySearch(c, new Circle("Apple",4));
		System.out.println("Index of Apple : "+idx);
	}

}
