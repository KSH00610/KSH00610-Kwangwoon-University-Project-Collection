package Test01;
import java.util.StringTokenizer;
public class Ex1 {
	
	public static void main(String[] args) {
		String s1 = "���ع��� ��λ��� ������ �⵵��";
		String s2 = "2020/11/03";
		String s3 = "2020��11��03��";
		int num=1;
		
		StringTokenizer st1= new StringTokenizer(s1," ");
		int count=st1.countTokens();
		System.out.println("s1 count: "+count);
		while(st1.hasMoreTokens())
		{
			System.out.println(num+":"+st1.nextToken());
			num++;
		}
		num=1;
		System.out.println();
		
		StringTokenizer st2= new StringTokenizer(s2,"/");
		count=st2.countTokens();
		System.out.println("s2 count: "+count);
		while(st2.hasMoreTokens())
		{
			System.out.println(num+":"+st2.nextToken());
			num++;
		}
		num=1;
		System.out.println();
		
		StringTokenizer st3= new StringTokenizer(s3,"�����");
		count=st3.countTokens();
		System.out.println("s3 count: "+count);
		while(st3.hasMoreTokens())
		{
			System.out.println(num+":"+st3.nextToken());
			num++;
		}
	}

}
