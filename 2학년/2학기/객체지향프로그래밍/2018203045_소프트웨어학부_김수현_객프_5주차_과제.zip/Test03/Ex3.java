package Test03;

public class Ex3 {

	public static void main(String[] args) {
		String text1 = "eW";
		String text2 = "LOVE";
		String text3 = "C++";
		String text4 = "programming.";
		StringBuilder str = new StringBuilder(text1);
		str.reverse();
		str.append(" "+text2.toLowerCase());
		text3=text3.concat("JAVA");
		str.append(" "+ text3.substring(3, text3.length()));
		str.append(" "+text4);
		System.out.println(str);
	}

}
