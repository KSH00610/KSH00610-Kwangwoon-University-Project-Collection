package Test02;

public class CurrencyConverter {
	static int exchange = 1121;
	static private int won;
	static private double dollar;
	public CurrencyConverter()
	{
		
	}
	public static void setRate(int money)
	{
		won = money*exchange;
	}
	public static double getRate()
	{
		return exchange;
	}
	public static double toDollar(int won)
	{
		dollar=(double)won/exchange;
		return dollar;
 	}
	public static double toKW(double dollar)
	{
		won=(int)dollar*exchange;
		return won;
	}
}
