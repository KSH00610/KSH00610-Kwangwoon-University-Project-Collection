package Test05;

public class ExId {
	static int num=0;
	static private int n=1;
	private int personal;
	
	public ExId()
	{
		num+=n;
		personal=num;
	}
	public static void setStep(int number)
	{
		n=number;
	}
	public int getId()
	{
		return personal;
	}
	public static int getMaxId()
	{
		return num;
	}
	public static int getStep()
	{
		return n;
	}

}
