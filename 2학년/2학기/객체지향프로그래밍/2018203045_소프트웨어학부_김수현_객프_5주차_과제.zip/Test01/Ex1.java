package Test01;

public class Ex1 {

	public static void main(String[] args) {
		String text = "I love you";
		for(int i=1; i<=text.length(); i++)
		{
			String text1 = text.substring(i, text.length())+text.substring(0,i);
			System.out.println(text1);
		}
		}

}
