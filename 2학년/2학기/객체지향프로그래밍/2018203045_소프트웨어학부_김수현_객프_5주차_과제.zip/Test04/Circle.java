package Test04;

public class Circle {
	private int x, y;
	private int radius;
	
	public String toString()
	{
		return "Circle("+x+","+y+") ������"+radius;
	}
	public Circle(int x, int y, int radius)
	{
		this.x=x;
		this.y=y;
		this.radius=radius;
	}
	public Circle(int x, int y)
	{
		this.x=x;
		this.y=y;
		radius=5;
	}
	public Circle(int radius)
	{
		x=0;
		y=0;
		this.radius=radius;
	}
	public boolean equals(Circle temp)
	{
		if(this.x==temp.x && this.y==temp.y)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

}
