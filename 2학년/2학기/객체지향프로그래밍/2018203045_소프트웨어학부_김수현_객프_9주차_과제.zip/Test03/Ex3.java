package Test03;

import java.util.Scanner;
import java.util.*;
public class Ex3 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		try {
			System.out.print("x�� : ");
			int x = scan.nextInt();
			System.out.print("y�� : ");
			int y = scan.nextInt();
			System.out.println("x * y = " + mul(x, y));
			System.out.println("x / y = " + div(x, y));
		}
		catch(InputMismatchException e)
		{	
			e.printStackTrace();
		}
		catch(ArithmeticException e)
		{
			e.printStackTrace();
		}
		catch(Throwable e)
		{
			e.printStackTrace();
		}
		finally
		{
			System.out.println("���α׷��� �����մϴ�.");
		}
	}
	static int mul(int x, int y) {
		// TODO Auto-generated method stub
		return x*y;
	}
	static double div(int x, int y) throws ArithmeticException {
		// TODO Auto-generated method stub
		if(y==0)
		{
			throw new ArithmeticException();
		}
		return (double)x/y;
	}
}
