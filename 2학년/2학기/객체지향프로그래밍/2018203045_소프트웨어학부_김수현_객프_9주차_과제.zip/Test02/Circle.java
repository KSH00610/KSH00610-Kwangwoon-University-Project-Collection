package Test02;

public class Circle extends Shape{
	private int radius;
	private static double PI = 3.14;
	
	public String getName()
	{
		return name;
	}
	public Circle(String name, int radius)
	{
		super(name);
		this.radius=radius;
	}
	public double getArea()
	{
		return radius*radius*PI;
	}
}
