package Test02;

public class Ex2 {

	public static void main(String[] args) {
		Shape[] arr = { new Circle("Circle", 5), 
				 new Rectangle("Rectangle", 3, 4), 
				new Triangle("Triangle", 5, 5) 
				 };
				 
		double sum = 0;
		for (Shape a : arr) {
			System.out.println(a.getName() + "���� : " + a.getArea());
			sum += a.getArea();
		}
			System.out.println("������ �� : " + sum);
	}
}
