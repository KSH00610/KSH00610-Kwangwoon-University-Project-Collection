package Test01;

public interface ExPlayer extends Player {
	void slow();
}
