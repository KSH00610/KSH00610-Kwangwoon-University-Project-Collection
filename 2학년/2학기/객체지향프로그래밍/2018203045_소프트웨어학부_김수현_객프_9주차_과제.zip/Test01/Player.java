package Test01;

public interface Player {
	void play();
	void stop();
}
