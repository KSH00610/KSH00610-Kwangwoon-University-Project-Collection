package Test01;

public class Ex1 {

	public static void main(String[] args) {
		DVDPlayer d = new DVDPlayer();
		Player p = new DVDPlayer();
		ExPlayer e = new DVDPlayer();
		System.out.println("*** DVDPlayer�� ���� d ***");
		d.play();
		d.stop();
		d.slow();
		System.out.println("*** Player�� ���� p ***");
		p.play();
		p.stop();
		System.out.println("*** ExPlayer�� ���� e ***");
		e.play();
		e.stop();
		e.slow();

	}

}
