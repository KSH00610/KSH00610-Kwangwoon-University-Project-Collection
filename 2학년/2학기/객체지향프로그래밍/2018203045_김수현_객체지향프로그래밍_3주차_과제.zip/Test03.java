package Test;

public class Test03 {

	public static void main(String[] args) {
		char a = 'e';
		for(char ch1 = a; ch1 >= 'a'; ch1--)
		{
			for(char ch2 ='a'; ch2 <= ch1; ch2++) {
				System.out.print(ch2);
			}
			System.out.println();
		}
	}

}
