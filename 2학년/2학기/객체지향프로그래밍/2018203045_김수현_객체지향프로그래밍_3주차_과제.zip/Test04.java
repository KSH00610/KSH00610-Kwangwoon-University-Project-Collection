package Test;

public class Test04 {

	public static void main(String[] args) {
		int number1 = 12321, number2 = 1232, result;
		result = palindrome(number1);
		resultPrint(number1, result);
		result = palindrome(number2);
		resultPrint(number2, result);

	}
	public static void resultPrint(int num1, int num2) {
		if (num1 == num2)
		 System.out.println(num2 + "�� ȸ���� �Դϴ�.");
		else
		 System.out.println(num2 + "�� ȸ������ �ƴմϴ�.");
		 }
	public static int palindrome(int num) {
		int num1=0, num2=0;
		int reverse=0;
		int tmp=num;
		while(tmp != 0)
		{
			num1=reverse*10;
			num2=tmp%10;
			reverse=num1+num2;
			tmp/=10;
		}
		return reverse;
		 }


}
