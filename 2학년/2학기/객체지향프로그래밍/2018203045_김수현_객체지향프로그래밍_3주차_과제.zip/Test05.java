package Test;

public class Test05 {

	public static void main(String[] args) {
		System.out.println("f(0) = "+f(0));
		System.out.println("f(1) = "+f(1));
		System.out.println("f(2) = "+f(2));
		System.out.println("f(3) = "+f(3));
		System.out.println("f(4) = "+f(4));
		System.out.println("f(5) = "+f(5));

	}
	public static int f(int num) {
		if(num==0)
		{
			return 1;
		}
		else
		{
			return 2*f(num-1)+1;
		}
	}

}
