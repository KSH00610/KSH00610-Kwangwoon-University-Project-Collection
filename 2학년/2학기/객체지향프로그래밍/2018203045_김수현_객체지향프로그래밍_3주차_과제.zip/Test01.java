package Test;

public class Test01 {

	public static void main(String[] args) {
		int cnt1=0;
		int cnt2=0;
		for(int i=1; i<=100; i++)
		{
			if(i % 8 ==0 && i % 9 == 0)
			{
				break;
			}
			if(i % 8 == 0)
			{
				cnt1++;
			}
			if(i % 9 == 0)
			{
				cnt2++;
			}
		}
		System.out.println("8�� ��� :"+cnt1+"��");
		System.out.println("9�� ��� :"+cnt2+"��");
	}

}
