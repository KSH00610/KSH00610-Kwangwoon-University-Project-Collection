package Test01;

public class Matrix {
	
	public Matrix()
	{
		
	}
	public void printMatrix(int[][] a)
	{
		for(int i=0; i< a.length; i++)
		{
			for(int j=0; j<a[i].length; j++)
			{
				System.out.print(a[i][j]);
			}
			System.out.println();
		}
		System.out.println();
	}
	public void addMatrix(int[][] a, int[][] b, int[][] c)
	{
		for(int i= 0; i<a.length; i++)
		{
			for(int j = 0; j<a[i].length; j++)
			{
				c[i][j]+=a[i][j]+b[i][j];
			}
		}
	}
}
