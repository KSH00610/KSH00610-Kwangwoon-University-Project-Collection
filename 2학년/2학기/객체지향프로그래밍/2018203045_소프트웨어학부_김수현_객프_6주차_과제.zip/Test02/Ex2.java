package Test02;

import java.util.Scanner;

public class Ex2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("�ѿ� �ܾ� �˻� ���α׷��Դϴ�.");
		while(true)
		{
			System.out.print("�ѱ� �ܾ�?");
			String word = sc.next();
			if(word.equals("�׸�"))
			{
				return;
			}
			Dictionary.kor2Eng(word);
		}
	}

}
