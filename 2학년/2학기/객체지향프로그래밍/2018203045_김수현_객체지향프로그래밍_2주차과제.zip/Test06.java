package Test;

public class Test06 {

	public static void main(String[] args) {
		byte n1=47;
		byte n2=21;
		System.out.println("&���:"+(n1&n2));
		System.out.println("|���:"+(n1|n2));

	}

}
