package Test;

public class Test07 {

	public static void main(String[] args) {
		int num=3;
		int result;
		result=(num<<4)-num;
		System.out.println("result:"+result);
	}

}
