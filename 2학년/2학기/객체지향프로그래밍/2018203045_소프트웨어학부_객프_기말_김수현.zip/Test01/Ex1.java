package Test01;

public class Ex1 {

	public static void main(String[] args) {
		int num=1;
		int sum=0;
		while(true)
		{
			
			if(num%2==0)
			{
				num=-num;
			}
			sum+=num;
			if(num%2==0)
			{
				num=-num;
			}
			if(sum >=100)
				break;
			num++;
		}
		System.out.println("num="+num);
		System.out.println("sum="+sum);
	}

}
