package Test04;

public class Ex4 {

	public static void main(String[] args) {
		int size=10;
		GQueue<String> stringQueue = new GQueue<>(size);
		stringQueue.enqueue("seoul");
		stringQueue.enqueue("busan");
		stringQueue.enqueue("LA");
		for(int i=0; i<size; i++) {
		String str = stringQueue.dequeue();
		if(str != null) System.out.println(str);
		}
		GQueue<Integer> intQueue = new GQueue<>(size);
		intQueue.enqueue(1);
		intQueue.enqueue(2);
		intQueue.enqueue(3);
		for(int i=0; i< size; i++) {
		Integer is = intQueue.dequeue();
		if(is != null) System.out.println(is);
		}
	}
}
