package Test04;

public class GQueue<T> {
	private Object[] arr;
	private int num;
	private int pre;
	public GQueue(int size)
	{
		arr = new Object[size];
		this.num=0;
		this.pre=0;
	}
	public void enqueue(T item)
	{
		if(num==arr.length)
			return;
		arr[num++]=item;
	}
	public T dequeue()
	{
		if(num==0)
			return null;
		else
			return (T) arr[pre++];
	}

}
