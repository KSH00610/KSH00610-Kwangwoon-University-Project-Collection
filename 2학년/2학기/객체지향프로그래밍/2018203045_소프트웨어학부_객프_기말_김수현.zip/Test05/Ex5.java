package Test05;

import java.util.ArrayList;
import java.util.Collections;

public class Ex5 {

	public static void main(String[] args) {
		ArrayList<Student> list = new ArrayList<>();
		list.add(new Student("�̼���", 100, 100, 100));
		list.add(new Student("ȫ�浿", 90, 70, 80));
		list.add(new Student("��ö��", 80, 80, 90));
		list.add(new Student("�̿���", 70, 90, 70));
		list.add(new Student("���ڹ�", 60, 100, 80));
		Collections.sort(list);
		System.out.println("���� 1");
		for(Student s : list)
			System.out.println(s);
		
		System.out.println("���� 2");
		Collections.sort(list, (o1, o2)->{Student s1 = (Student)o1;
										Student s2 = (Student)o2;
										return s1.getName().compareTo(s2.getName());});
		for(Student s : list)
		System.out.println(s);

	}

}
