package Test05;

public class Student implements Comparable<Student>{
	private String name;
	private int score1;
	private int score2;
	private int score3;
	private int result;
	
	public Student(String name, int sc1, int sc2, int sc3)
	{
		this.name=name;
		this.score1=sc1;
		this.score2=sc2;
		this.score3=sc3;
		this.result=sc1+sc2+sc3;
	}
	public String getName()
	{
		return name;
	}
	public String toString()
	{
		return name+" : "+result+" ("+score1+","+score2+","+score3+")";
	}
	@Override
	public int compareTo(Student o) {
		return this.result-o.result;
	}
	
}
