package Test02;

public class Ex2 {

	public static void main(String[] args) {
		StringBuffer sb= new StringBuffer("Strawberry Grape Pear Apple");
		System.out.println("capacity : 10");
		String sub1 = sb.toString();
		System.out.println("StringBuffer : "+sub1);
		System.out.println("capacity : 27");
		String sub2 = sb.substring(0,16);
		System.out.println("StringBuffer : "+sub2);
		System.out.println("capacity : 16");
		String sub3= sb.substring(0, 11)+sb.substring(17,22)+sb.substring(11,16);
		System.out.println("StringBuffer : "+sub3);
		System.out.println("capacity : 34");
		String sub4 = sb.substring(22)+sb.substring(16, 22)+sb.substring(11, 16);
		System.out.println("StringBuffer : "+sub4);
		System.out.println("capacity : 34");
	}

}
