package Test03;

public class Ex3 {

	public static void main(String[] args) {
		Shape [] list = { new Circle(20), 
				 		new Oval(20, 30), new Rect(20, 30)};
				
		for (Shape a : list) 
			a.draw();
		for (Shape a : list) 
			System.out.println("������ " + a.getArea());

	}

}
