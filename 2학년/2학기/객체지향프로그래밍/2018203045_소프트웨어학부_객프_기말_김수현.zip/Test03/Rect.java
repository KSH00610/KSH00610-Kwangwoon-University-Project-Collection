package Test03;

public class Rect implements Shape{
	private int x;
	private int y;
	
	public Rect(int x, int y)
	{
		this.x=x;
		this.y=y;
	}
	@Override
	public void draw() {
		System.out.println(x+"X"+y+"ũ���� �簢���Դϴ�.");
	}

	@Override
	public double getArea() {
		return x*y;
	}

}
