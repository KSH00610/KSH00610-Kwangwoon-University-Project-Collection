package Test03;

public class Oval implements Shape{
	private int x;
	private int y;
	
	public Oval(int x, int y)
	{
		this.x=x;
		this.y=y;
	}
	@Override
	public void draw() {
		System.out.println(x+"X"+y+"0�� �����ϴ� Ÿ���Դϴ�.");
	}

	@Override
	public double getArea() {
		return x*y*PI;
	}

}
