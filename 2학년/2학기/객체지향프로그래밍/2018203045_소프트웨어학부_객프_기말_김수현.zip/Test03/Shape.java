package Test03;

public interface Shape {
	final double PI = 3.14;
	void draw(); 
	double getArea(); 
}
