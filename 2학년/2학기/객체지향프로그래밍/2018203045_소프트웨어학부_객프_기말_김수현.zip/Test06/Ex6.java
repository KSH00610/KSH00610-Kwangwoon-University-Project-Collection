package Test06;

import java.util.ArrayList;
import java.util.List;
import java.util.function.IntUnaryOperator;
import java.util.function.Predicate;
import java.util.function.UnaryOperator;

public class Ex6 {

	public static void main(String[] args) {
		List<String> list = new ArrayList<>();
		list.add("David");
		list.add("Thomas");
		list.add("Bill");
		list.add("Eric");
		list.add("Ford");
		System.out.println(list);
		Predicate<String> ip = i -> {
			if(i.contains("D"))
				return true;
			else
				return false;
		};
		list.removeIf(ip);
		System.out.println(list);
		UnaryOperator<String> iu = u -> {
			return u.toUpperCase();
		};
		replaceAlpha(iu,list);
		System.out.println(list);
	}
	private static void replaceAlpha(UnaryOperator<String> u, List<String> list) {
		for(int i = 0; i< list.size(); i++) {
			list.set(i, u.apply(list.get(i)));
		}
	}
}
