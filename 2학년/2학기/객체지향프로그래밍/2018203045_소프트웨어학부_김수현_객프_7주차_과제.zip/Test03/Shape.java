package Test03;

public class Shape {
	protected String name;
	
	public Shape(String name)
	{
		this.name=name;
	}
	public String getName()
	{
		return name;
	}
	public double getArea()
	{
		return 0;
	}
}
