package Test03;

public class Rectangle extends Shape{
	private int x;
	private int y;
	
	public String getName()
	{
		return name;
	}
	public Rectangle(String name, int x, int y)
	{
		super(name);
		this.x=x;
		this.y=y;
	}
	public double getArea()
	{
		return x*y;
	}
	
}
