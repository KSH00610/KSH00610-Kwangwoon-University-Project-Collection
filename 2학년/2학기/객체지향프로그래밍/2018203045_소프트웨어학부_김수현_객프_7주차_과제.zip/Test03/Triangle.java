package Test03;

public class Triangle extends Shape{
	private int width;
	private int height;
	
	public String getName()
	{
		return name;
	}
	public Triangle(String name, int width, int height)
	{
		super(name);
		this.width=width;
		this.height=height;
	}
	public double getArea()
	{
		return width*height/2.0;
	}
}
