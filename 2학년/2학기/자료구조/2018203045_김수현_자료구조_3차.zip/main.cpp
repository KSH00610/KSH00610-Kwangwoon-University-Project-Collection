#include <iostream>
#include <string>
#include <cstdlib>
#include <cassert>
#include <algorithm>
#include <cctype>
#include <cstring>
#include <stdio.h>

using namespace std;

template <class Item>
class set
{
private:
	static const size_t min = 200;
	static const size_t max = 2 * min;
	size_t data_count;
	Item data[max + 1];
	size_t child_count;
	set* subset[max + 2];

public:
	set();
	set(Item in[], set* su[]);
	int count(Item& target);
	bool insert(Item& input);
	bool loose_insert(Item& entry);
	void fix_excess(size_t i);
	bool erase(Item& input);
	bool loose_erase(Item& entry);
	void fix_shortage(size_t i);
};

template <class Item>
bool set<Item>:: loose_insert(Item& entry)
{
	int i = 0;
	while (true)
	{
		if (data[i] >= entry)
			break;
		i++;
	}
	if (data[i] == entry)
		return false;
	else if (subset[i] == NULL)
	{
		for (int j = i; j < max + 1; j++)
		{
			data[j + 1] = data[j];
		}
		data[i] = entry;
		return true;
	}
	else if
	{
		bool b = subset[i]->loose_insert(entry);
		if (subset[i].size() > max + 1)
		{
			fix_excess((size_t)i);

		}
		return b;
	}
}

template<class Item>
void set<Item>::fix_excess(size_t i)
{

}

template <class Item>
set<Item>::set()
{
	std::fill_n(data.MAXIMUM + 1, NULL);
	data_count = 0;
	child_count = 0;
}

template <class Item>
set<Item>::set(Item in[], set* su[])
{
	for (int i = 0; i < in.size(); i++)
	{
		data[i] = in[i];
	}
	for (int i = 0; i < su.size(); i++)
	{
		*(sub+i) = *(su + i);
	}
}

template<class Item>
int set<Item>::count(Item& target)
{
	int i = 0;
	while (true)
	{
		if (this->data[i] >= target)
		{
			break;
		}
		i++;
	}
	if (this.data[i] == target)
		return 1;
	else if (this.subset[i] == NULL)
		return 0;
	else
		return count(target);
}

template<class Item>
bool set<Item>::insert(Item& input)
{
	if (data_count == max + 1)
	{

	}
}

template<class Item>
bool set<Item>::erase(Item& input)
{
	if (loose_erase(input))
		return false;
	if ((data_count == 0) && (child_count == 1))
	{
		
		return true;
	}
}

template<class Item>
bool set<Item>::loose_erase(Item& input)
{
	int i = 0;
	while (true)
	{
		if (data[i] >= input)
			break;
		i++;
	}
	if (subset[i] == NULL && subset[i + 1] = NULL && data[i] != input)
		return false;
	else if (subset[i] == NULL && subset[i + 1] = NULL && data[i] == input)
	{
		for (intj = i; j < max + 1; j++)
		{
			data[j] = data[j + 1];
		}
		return true;
	}
	else
	{
		bool b = subset[i]->loose_erase(input);
		if (subset[i].size() > min - 1)
		{
			fix_shortage(i);
		}
		else
	}
}

template<class Item>
void set<Item>::fix_shortage(size_t i)
{

}