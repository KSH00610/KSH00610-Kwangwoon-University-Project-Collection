#include <stdio.h>
#include <string.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <array>
#include <vector>
#include <iostream>

using namespace std;

int kor, math, eng, his;

int common_subject_cutline[4][8]={{83,75,68,59,46,35,24,17},{85,75,65,53,34,20,14,9},{90,80,70,60,50,40,30,20},{40,35,30,25,20,15,10,5}};	

int science_subject_cutline[8][8]={{44,40,34,29,22,16,11,7},{46,43,40,32,23,15,10,7},{43,40,35,28,20,14,9,6},{44,38,33,28,20,16,10,7},{47,43,39,31,20,14,10,6},{47,44,37,30,21,14,10,7},{45,42,39,32,21,14,10,7},{40,36,31,25,18,12,9,6}};

int literati_subject_cutline[9][8]={{46,43,36,31,23,16,11,7},{47,43,37,28,18,13,9,6},{48,45,40,31,21,15,10,7},{50,46,40,30,21,14,9,6},{48,45,41,31,20,14,10,6},
{50,45,38,23,14,12,7,5},{48,45,41,29,23,14,10,7},{48,45,36,24,16,14,10,7},{47,43,38,32,23,16,10,7} };

vector<int> all_subjects_grade;	

void common_subject_score()
{
	cout << "Korean Score : ";
        cin >> kor;
        cout << "Math  Score : ";
        cin >> math;
        cout << "English Score : ";
	cin >> eng;
	cout << "History Score : ";
	cin >> his;
}

int common_subject_grade(int sub_num, int score)
{	
	int sub = sub_num;
	int grade=0;
	if(score >= common_subject_cutline[sub][0])
		grade=1;
	else if(score >= common_subject_cutline[sub][1])
		grade=2;
	else if(score >= common_subject_cutline[sub][2])
                grade=3;
	else if(score >= common_subject_cutline[sub][3])
                grade=4;
	else if(score >= common_subject_cutline[sub][4])
                grade=5;
	else if(score >= common_subject_cutline[sub][5])
                grade=6;
	else if(score >= common_subject_cutline[sub][6])
                grade=7;
	else if(score >= common_subject_cutline[sub][7])
                grade=8;
	else
		grade=9;

	return grade;
}

int science_subject_grade(string sub, int score)
{
	int grade=0;
	int sub_num;
	if(sub == "Physics 1")
		sub_num=0;
	else if(sub == "Chemistry 1")
		sub_num=1;
	else if(sub == "Biology 1")
		sub_num=2;
	else if(sub == "Earth Science 1")
		sub_num=3;
	else if(sub == "Physics 2")
		sub_num=4;
	else if(sub == "Chemistry 2")
                sub_num=5;
	else if(sub == "Biology 2")
                sub_num=6;
	else
		sub_num=7;
	
	if(score >= science_subject_cutline[sub_num][0])
                grade=1;
        else if(score >= science_subject_cutline[sub_num][1])
                grade=2;
        else if(score >= science_subject_cutline[sub_num][2])
                grade=3;
        else if(score >= science_subject_cutline[sub_num][3])
                grade=4;
        else if(score >= science_subject_cutline[sub_num][4])
                grade=5;
        else if(score >= science_subject_cutline[sub_num][5])
                grade=6;
        else if(score >= science_subject_cutline[sub_num][6])
                grade=7;
        else if(score >= science_subject_cutline[sub_num][7])
                grade=8;
        else
                grade=9;

        return grade;

}

int literati_subject_grade(string sub, int score)
{
        int grade=0;
        int sub_num;

        if(sub == "Life & Ethics")
                sub_num=0;
        else if(sub == "Ethics & Ideology")
                sub_num=1;
        else if(sub == "Korean Geography")
                sub_num=2;
        else if(sub == "World Geography")
                sub_num=3;
	else if(sub == "East Asia History")
		sub_num=4;
	else if(sub == "World History")
                sub_num=5;
	else if(sub == "Politics & Law")
                sub_num=6;
	else if(sub == "Economy")
                sub_num=7;
	else
                sub_num=8;

        if(score >= literati_subject_cutline[sub_num][0])
                grade=1;
        else if(score >= literati_subject_cutline[sub_num][1])
                grade=2;
        else if(score >= literati_subject_cutline[sub_num][2])
                grade=3;
        else if(score >= literati_subject_cutline[sub_num][3])
                grade=4;
        else if(score >= literati_subject_cutline[sub_num][4])
                grade=5;
        else if(score >= literati_subject_cutline[sub_num][5])
                grade=6;
        else if(score >= literati_subject_cutline[sub_num][6])
                grade=7;
        else if(score >= literati_subject_cutline[sub_num][7])
                grade=8;
        else
                grade=9;

        return grade;

}

void show_all_grade(vector<int> v)
{
	cout << "Korean " << "\t" << "Math" << "\t" << "English" << "\t" << "History" << "\t" << "Select1" << "\t" << "Select2" <<endl;
	for(int i=0; i<v.size(); i++)
	{
		cout << v[i] << "\t";
	}
	cout << endl;
}	
void show_final_grade(vector<int> v)
{
	double sum=0;
	for(int i=0; i<v.size(); ++i)
	{
		sum+=v[i];
	}
	double result = (double)sum/v.size();
	cout << "Your Grade : " << result << endl;
}

int main(void){
	int kor_grade;
	int math_grade;
	int eng_grade;
	int his_grade;
	int sel1_grade;
	int sel2_grade;

	cout<< " Korea SAT" << endl;
	cout << "Which are you join (science or literati?)" << endl;
	string select;
	cin >> select;
	
	if(select == "science"){
		cout << "What are your select subject?" << endl;
		cout << "[1. Physics 1] [2. Chemistry 1] [3. Biology 1] [4. Earth Science 1] [5. Physics 2] [6. Chemistry 2] [7. Biology 2] [8. Earth Science 2]  " << endl;
		array<string, 8> subject = {"Physics 1", "Chemistry 1", "Biology 1", "Earth Science 1", "Physics 2", "Chemistry 2", "Biology 2", "Earth Science 2"};
		re1:
		cout << "Select the nunbers" << endl;   
		int sel1, sel2;
		cin >> sel1;
		cin >> sel2;
		if(sel1 < 1 || sel1 > 8 || sel2 < 1 || sel2 >8)
		{
			cout << "Wrong input" <<endl;
			goto re1;
		}
		cout << "Your select subjects are " << subject[sel1-1] <<", " << subject[sel2-1] << endl << endl; 	
		common_subject_score();
		cout << subject[sel1-1] << " Score : ";
		int science1;
		cin >> science1;
		cout << subject[sel2-1] << " Score : ";
                int science2;
                cin >> science2; 
		kor_grade = common_subject_grade(0, kor);
		all_subjects_grade.push_back(kor_grade);
		math_grade = common_subject_grade(1, math);
		all_subjects_grade.push_back(math_grade);
		eng_grade = common_subject_grade(2, eng);
		all_subjects_grade.push_back(eng_grade);
		his_grade = common_subject_grade(3, kor);
		all_subjects_grade.push_back(his_grade);
		sel1_grade=science_subject_grade(subject[sel1-1], science1);
		all_subjects_grade.push_back(sel1_grade);
		sel2_grade=science_subject_grade(subject[sel2-1], science2);
                all_subjects_grade.push_back(sel2_grade);

		show_all_grade(all_subjects_grade);
		show_final_grade(all_subjects_grade);
	}
	else{
		 cout << "What are your select subject?" << endl;
                cout << "[1. Life & Ethics] [2. Ethics & Ideology] [3. Korean Geography] [4. World Geography] [5. East Asia History] [6. World History] [7. Politics & Law] [8. Economy] [9. Social Culture]" << endl;
                array<string, 9> subject = {"Life & Ethics", "Ethics & Ideology", "Korean Geography", "World Geography", "East Asia History", "World History", "Politics & Law", "Economy", "Social Culture"};
                re2:
                cout << "Select the nunbers" << endl;
                int sel1, sel2;
                cin >> sel1;
                cin >> sel2;
                if(sel1 < 1 || sel1 > 9 || sel2 < 1 || sel2 >9)
                {
                        cout << "Wrong input" <<endl;
                        goto re2;
                }
                cout << "Your select subjects are " << subject[sel1-1] <<", " << subject[sel2-1] << endl << endl;
                common_subject_score();
                cout << subject[sel1-1] << " Score : ";
                int literati1;
                cin >> literati1;
                cout << subject[sel2-1] << " Score : ";
                int literati2;
                cin >> literati2;
                kor_grade = common_subject_grade(0, kor);
                all_subjects_grade.push_back(kor_grade);
                math_grade = common_subject_grade(1, math);
                all_subjects_grade.push_back(math_grade);
                eng_grade = common_subject_grade(2, eng);
                all_subjects_grade.push_back(eng_grade);
                his_grade = common_subject_grade(3, kor);
                all_subjects_grade.push_back(his_grade);
                sel1_grade=literati_subject_grade(subject[sel1-1], literati1);
                all_subjects_grade.push_back(sel1_grade);
                sel2_grade=literati_subject_grade(subject[sel2-1], literati2);
                all_subjects_grade.push_back(sel2_grade);
		cout<<endl;
                show_all_grade(all_subjects_grade);
		cout<<endl;
                show_final_grade(all_subjects_grade);

	}
}
