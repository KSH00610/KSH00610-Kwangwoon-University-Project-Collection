package Assignment;

public class Record {//링버퍼에 들어갈 데이터들의 필요한 정보를 저장하는 클래스입니다.
	int id;//해당 데이터의 id로써 unquie한 값으로 이것으로 데이터의 구분자 역할을 수행합니다.
	int value;// 해당 데이터의 값으로 실제 데이터의 정보를 의미합니다.

	public Record(int id, int value) {//생성자를 이용해 데이터의 id, 실제 정보를 지정해 줍니다.
		this.id=id;
		this.value=value;
	}
}
