package Assignment;

public class main {

	public static void main(String[] args) {
		int size=10;//버퍼의 크기를 임의로 지정합니다
		Buffer buffer = new Buffer(size);
		Thread producer = new Thread(() -> {//producer 스레드를 생성합니다.
			try {
				for(int i=0; i<10; i++) {
					Record record = new Record(i, i*10);
					buffer.insert(record);//링버퍼에 데이터를 삽입합니다.
					System.out.println("Producer insert new record - "+ record.id+" / "+record.value);
					Thread.sleep(1000);//1초간 대기를 합니다.
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		});
		Thread consumer = new Thread(()->{//consumer 스레드를 생성합니다.
			try {
				for(int i=0; i<10; i++) {
					Record record = buffer.get();//링버퍼에서 데이터를 가져옵니다.
					System.out.println("Consumer use record - "+ record.id+" / "+record.value);
					Thread.sleep(1500);//1.5초간 대기합니다.
				}
				
			} catch (InterruptedException e){
				e.printStackTrace();
			}
		});
		
		producer.start();
		consumer.start();
		//producer, consumer 스레드 모두 실행합니다.
		try {
			producer.join();
			consumer.join();
			//producer, consumer 스레드의 종료를 기다립니다.
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
