package Assignment;

public class Buffer {//링버퍼의 형태를 구현한 클래스입니다.
	int size;//링버퍼의 사이즈 즉 들어갈 수 있는 데이터들의 용량/갯수을 나타냅니다.
	int num=0;//링버퍼의 들어간 데이터들의 갯수입니다.
	int start=0;//링버퍼의 시작위치로써 링버퍼에서 데이터 읽을 시에 위치를 지정합니다.
	int end=0;//링버퍼의 끝위치로써 링버퍼에 데이터가 삽입 시 들어갈 위치를 지정합니다.
	Record[] record;//링버퍼에 데이터 저장 담당하는 배열입니다.
	
	public Buffer(int n) {
		this.size=n;
		this.record = new Record[n];
	}//링버퍼의 사이즈와 데이터를 저장할 배열의 크기를 할당합니다.
	
	public synchronized void insert(Record rec) throws InterruptedException {//데이터 삽입 담당함수
		if(num == size) {
			wait();//링버퍼가 가득차면 즉 링버퍼의 용량이 가득 차면 대기합니다.
		}
		record[end] = new Record(rec.id, rec.value);
		end = (end+1) % size; // end 이동해 데이터가 들어갈 위치를 지정하고 데이터 삽입, 여기서 size로 나누는 이유는 링버파가 원형이므로 순환하는 구조여서입니다.
		num++;
		notify(); // 대기 중인 스레드를 깨웁니다.
	}
	public synchronized Record get() throws InterruptedException {
        Record result = null;
        
        if (num == 0)
            wait(); // 링버퍼에 들어간 데이터가 없으면 대기합니다.
        
        result = record[start];//읽을 위치 즉 start위치의 데이터를 가져옵니다.
        start = (start + 1) % size;//start 이둉해 다음 읽을 위치로 이동시킵니다. size로 나누는 이유는 위의 end와 같습니다.
        num--;
        
        notify();//대기 중 스레드를 깨웁니다.
        
        return result;//가져온 데이터를 반환값으로 지정하여 반환합니다.
    }
}
