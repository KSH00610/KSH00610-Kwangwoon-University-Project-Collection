#!/bin/bash

docker stop cs3864
docker rm cs3864
