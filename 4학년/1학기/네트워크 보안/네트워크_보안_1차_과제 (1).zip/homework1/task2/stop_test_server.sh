#!/bin/bash
docker stop task2
docker rm task2
