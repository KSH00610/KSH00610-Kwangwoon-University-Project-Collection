#!/bin/bash

service ssh start
service vsftpd start
service apache2 start
bash