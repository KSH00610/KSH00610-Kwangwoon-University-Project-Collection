#!/usr/bin/env python
# coding: utf-8

# In[3]:


import pyautogui
import pyperclip
from subprocess import Popen
import time

x, y = (580, 1050) #윈도우 11 기준 바탕화면 검색 창의 좌표입니다.
pyautogui.click(x, y) #click함수를 사용해 검색 창을 활성화시킵니다.
time.sleep(1.0) #검색창이 활성화될 때까지 시간이 걸리므로 sleep을 이용해 1초 동안 대기합니다.
command = 'Anaconda Prompt'
pyperclip.copy(command) #한영키 활성화 상황에 따라 한글로 command가 입력되는 것을 방지하기 위해 pyperclip.copy를 사용해 command를 복사합니다.
pyautogui.hotkey('ctrl', 'v') #키보드 자동화를 이용해 ctrl+v 즉 붙혀넣기 기능을 준비합니다.
pyautogui.press('enter') #enter를 눌르는 키보드 자동화로 ctrl+v 즉 붙혀넣기 기능을 활성화합니다.
time.sleep(1.0) #Anaconda Prompt가 활성화될 때까지 시간이 걸리므로 sleep을 이용해 1초간 대기합니다.
pyautogui.hotkey('win','up') #window키+up을 이용해 Anaconda Prompt 크기를 최대화 시킵니다.
time.sleep(1.0) #Anaconda Prompt가 최대화될 때까지 시간이 걸리므로 sleep을 이용해 1초간 대기합니다.
command = 'idle' 
pyautogui.typewrite(command, interval=0.1) #interval을 0.1로 해 사람이 입력하는 것과 같이 command 변수에 저장되는 값을 Anaconda Prompt에 타이핑합니다.
pyautogui.press('enter') #enter를 눌러 idle을 활성화합니다.
time.sleep(1.0) #idle 활성화될 때까지 시간이 걸리므로 sleep을 이용해 1초간 대기합니다.
pyautogui.hotkey('win','up') #window키+up을 이용해 idle 크기를 최대화 시킵니다.
time.sleep(1.0) #idle 최대화될 때까지 시간이 걸리므로 sleep을 이용해 1초간 대기합니다.
pyautogui.hotkey('win','left') #window키+left를 이용해 idle을 왼쪽 가장자리 위치시킵니다.
pyautogui.press('esc') #esc를 눌러 활성화된 창분리 기능을 무효화시킵니다.
with open("C:\\4_2\\python\\turtle_file.txt", "r") as f: #1차과제였던 터틀 그래픽의 텍스트 파일을 읽습니다.
    for line in f:
        pyautogui.typewrite(line, interval=0.1) #interval을 0.1로 설정해 사람이 타이핑 하는 것처럼 텍스트파일을 한 줄 씩 타이핑합니다.
        pyautogui.press('enter') #enter키를 눌러 작성한 파이썬 명령어를 실행합니다.
        if line.strip() == "t=turtle.Turtle()": #명령어가 t=turtle.Turtle()인 경우 turtle을 그리는 창이 가운데 활성화됩니다.
            pyautogui.click(1000,600) #turtle 그리는 창을 누릅니다.
            pyautogui.hotkey('win','right') #turtle 그리는 창을 오른쪽 가장자리에 위치시킵니다.
            pyautogui.click(320,500) #키보드 자동화를 통해 명령어가 이어나갈 수 있게 idle 창을 클릭합니다.
        time.sleep(3.0) #파이썬 명령어 활성화 시 수행하는데 시간이 걸리므로 sleep를 이용해 명령 수행이 끝날 때까지 대기합니다,


# In[ ]:




