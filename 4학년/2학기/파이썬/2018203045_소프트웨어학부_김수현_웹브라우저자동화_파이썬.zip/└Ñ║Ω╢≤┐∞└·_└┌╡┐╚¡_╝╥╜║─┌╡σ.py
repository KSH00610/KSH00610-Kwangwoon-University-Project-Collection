#!/usr/bin/env python
# coding: utf-8

# In[3]:


from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
import time
from tqdm import tqdm_notebook
import pandas as pd
from glob import glob

driver = webdriver.Chrome()
url = 'https://www.opinet.co.kr/searRgSelect.do'
driver.get(url)
time.sleep(3)
oils_list = driver.find_element(By.XPATH,"""//*[@id="SIGUNGU_NM0"]""")
time.sleep(1)
oils = oils_list.find_elements(By.TAG_NAME, "option")
time.sleep(1)
oils_name =[option.get_attribute("value") for option in oils]
oils_name.remove('')
oils_name
for oil in tqdm_notebook(oils_name):
    element_ID = driver.find_element(By.ID, 'SIGUNGU_NM0')
    element_ID.send_keys(oil)
    time.sleep(3)
    xpath1="""//*[@id="searRgSelect"]"""
    element_XPATH = driver.find_element(By.XPATH, xpath1).click()
    time.sleep(3)
    xpath2="""//*[@id="glopopd_excel"]"""
    element_EXCEL = driver.find_element(By.XPATH, xpath2).click()
    time.sleep(3)


folder_path = "C:/Users/spanc/Downloads/지역*.xls"
oil_files = glob(folder_path)
all_data_list = []

for file in oil_files:
    tmp = pd.read_excel(file, header=2)
    all_data_list.append(tmp)

selected_columns = ['지역', '상호', '주소', '상표', '전화번호', '셀프여부', '고급휘발유', '휘발유', '경유', '실내등유']

all_data = pd.concat(all_data_list)

all_data = all_data[selected_columns]
df=pd.DataFrame(all_data)
df.to_excel("서울시_주유소_가격.xlsx", index=False)
df

