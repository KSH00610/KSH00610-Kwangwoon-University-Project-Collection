#!/usr/bin/env python
# coding: utf-8

# In[3]:


from bs4 import BeautifulSoup # BeautifulSoup 모듈 불러오기
import requests # requests 모듈 불러오기
import pandas as pd # pandas 모듈 불러오기

import datetime # datetime 모듈 불러오기
import os # os 모듈 불러오기

today_date = datetime.datetime.now().strftime("%y%m%d") # 현재 날짜 정보를 'yymmdd' 형식의 문자열로 저장

# 주식 코드 및 네이버 금융 주식 페이지 URL 지정
code = '035250'
url = f'https://finance.naver.com/item/sise_day.naver?code={code}'
headers={'User-agent':'Mozilla/5.0'} # HTTP 요청을 위한 헤더 설정

# 네이버 금융 페이지에서 데이터 가져오기
req=requests.get(url, headers=headers) # HTTP GET 요청 보내기
html = BeautifulSoup(req.text,'lxml') # HTML 파싱을 위해 BeautifulSoup 객체 생성

# 마지막 페이지 정보 가져오기
pgrr = html.find('td', class_='pgRR') # '맨뒤' 버튼 요소 찾기
print(pgrr.a['href'])
s=pgrr.a['href'].split('=')
print(s)
last_page=s[-1] # 페이지 수를 추출하여 마지막 페이지 번호 저장
print(last_page)

# 빈 데이터프레임 생성
df = None

# 모든 페이지에 대한 데이터 수집
for page in range(1,int(last_page)+1): # 첫 페이지부터 마지막 페이지까지 반복
    req = requests.get(f'{url}&page={page}', headers = headers) # 각 페이지에 대한 HTTP GET 요청
    df = pd.concat([df, pd.read_html(req.text, encoding = 'euc-kr')[0]], ignore_index = True)  # 데이터프레임 합치기

# 결측치 제거 및 데이터프레임 재설정
df.dropna(inplace=True)
df.reset_index(drop=True, inplace=True)
df
file_name = f"kangwon_price_{today_date}.xlsx"# 파일 이름 설정
df.to_excel(file_name) # 데이터프레임을 엑셀 파일로 저장
df = pd.read_excel(file_name)# 엑셀 파일에서 데이터프레임으로 읽어오기
df
df.head()# 데이터프레임의 처음 몇 줄 출력
close = df['종가'] # '종가' 열의 데이터를 가져와 변수에 저장
close
close.shift(-1)# 종가의 다음 날과의 변동률 계산

# 일간 변동률 계산 및 마지막 행의 값이 NaN인 경우 0으로 설정
daily_rate = (close / close.shift(-1)-1)*100
daily_rate
daily_rate.iloc[-1]=0
daily_rate.tail()

# 데이터프레임에 일간 변동률 열 추가
df['일간변동률(%)']=daily_rate
df

# 일정 기간의 데이터 추출 및 역순으로 재정렬
df_target = df.loc[0:300] # 300일치 데이터 추출
df_target=df_target.loc[::-1] # 데이터프레임 역순으로 재배열
df_target.reset_index(drop=True, inplace=True) # 인덱스 재설정
df_target
cs =df_target['일간변동률(%)'].cumsum()# 누적 일간 변동률 계산
cs

# matplotlib을 사용하여 주식 가격 변동 그래프 그리기
import matplotlib.pyplot as plt # matplotlib 모듈 불러오기
get_ipython().run_line_magic('matplotlib', 'inline')
plt.figure(figsize=(10,8)) # 그래프 크기 설정
plt.plot(df_target['날짜'], cs, 'b', label='daily change(Kwangwon)') # 그래프 생성
plt.ylabel('Change %')# y축 라벨 설정
plt.grid(True) # 그리드 추가
plt.legend(loc='best') # 범례 위치 설정
plt.xticks(range(0,301,50)) # x축 눈금 설정
img_name = f"kwanwon_graph_{today_date}.png" # 이미지 파일 이름 설정
plt.savefig(img_name) # 그래프를 이미지 파일로 저장
plt.show() # 그래프 출력

import pyautogui # pyautogui 모듈 불러오기
import pyperclip # pyperclip 모듈 불러오기

# 카카오톡 아이콘의 위치 찾기 및 더블 클릭
r=pyautogui.locateCenterOnScreen("C:/4_2/python/kakaoicon.png")
r
pyautogui.doubleClick(r.x, r.y)

import time # time 모듈 불러오기
time.sleep(3.0)
pyautogui.hotkey('win','up')
time.sleep(1.0)
pyautogui.click(40,145) # 카카오톡 채팅방 찾기 클릭
time.sleep(1.0)
pyautogui.hotkey('ctrl', 'f')#카카오톡 이름으로 방 찾는데 활용
time.sleep(2.0)
name = "김수현" # 찾고자하는 대상 이름 저장
pyperclip.copy(name)
pyautogui.hotkey('ctrl', 'v') # 복사붙혀넣기 기능 이용해 채팅방 찾기
time.sleep(1.0)
pyautogui.press('enter') # 채팅방 활성화

file_paths = [
    file_name,
    img_name
] # 보내고자 즉 생성한 엑셀, 이미지 파일을 배열 형태로 저장

for file_path in file_paths:
    pyautogui.hotkey('ctrl', 't') # 카카오톡 파일 보내기 기능 활성화
    pyperclip.copy(file_path)
    pyautogui.hotkey('ctrl', 'v') # 앞서 저장한 배열의 값을 복사 붙혀넣기
    pyautogui.press('enter') # 엔터키 누름으로써 보내고자히는 파일 적재
    pyautogui.press('enter') # 엔터키 누름으로써 파일 보내기
    time.sleep(3.0)

